using System;
using System.IO;
using WebExpress.LLM.Gguf;
using Xunit;

namespace WebExpress.LLM.Test.Gguf;

/// <summary>
/// Phase-1 round-trip tests for the GGUF header parser and F32 / F16 / BF16
/// dequantization. Each test builds a synthetic GGUF file with
/// <see cref="GgufTestWriter"/>, opens it via <see cref="GgufLoader"/>, and
/// asserts the decoded tensors match the originals byte-for-byte (modulo
/// F16 / BF16 precision loss).
/// </summary>
public sealed class UnitTestGgufLoader
{
    [Fact]
    public void Open_WithValidMagicAndVersion_ParsesHeader()
    {
        var bytes = GgufTestWriter.Build(
            metadata: new[]
            {
                new GgufTestWriter.MetadataEntry { Key = "general.architecture", Value = "gemma4" },
            },
            tensors: new[]
            {
                new GgufTestWriter.TensorEntry
                {
                    Name = "test.weight",
                    Shape = new ulong[] { 4, 4 },
                    Type = GgufType.F32,
                    Data = new float[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 }
                }
            });

        using var loader = WriteAndOpen(bytes);
        Assert.Equal(3u, loader.Header.Version);
        Assert.Equal("gemma4", loader.Header.Metadata["general.architecture"]);
        Assert.Single(loader.TensorNames);
        Assert.True(loader.ContainsTensor("test.weight"));
    }

    [Fact]
    public void LoadTensor_F32_ReturnsExactValues()
    {
        var data = new float[] { 0.25f, -0.5f, 1.5f, -3.75f, 100f, 0f, -1e-6f, 7.7f };
        var bytes = GgufTestWriter.Build(
            tensors: new[]
            {
                new GgufTestWriter.TensorEntry
                {
                    Name = "linear.weight",
                    Shape = new ulong[] { 2, 4 },
                    Type = GgufType.F32,
                    Data = data
                }
            });

        using var loader = WriteAndOpen(bytes);
        var tensor = loader.LoadTensor("linear.weight");
        Assert.Equal(new[] { 2, 4 }, tensor.Shape);
        Assert.Equal(data.Length, tensor.Length);
        for (var i = 0; i < data.Length; i++)
        {
            Assert.Equal(data[i], tensor[i]);
        }
    }

    [Fact]
    public void LoadTensor_F16_DequantizesWithinTolerance()
    {
        var data = new float[] { 0.25f, -0.5f, 1.5f, -3.75f, 100f, 0f, -1e-3f, 7.7f };
        var bytes = GgufTestWriter.Build(
            tensors: new[]
            {
                new GgufTestWriter.TensorEntry
                {
                    Name = "linear.weight",
                    Shape = new ulong[] { 2, 4 },
                    Type = GgufType.F16,
                    Data = data
                }
            });

        using var loader = WriteAndOpen(bytes);
        var tensor = loader.LoadTensor("linear.weight");

        // F16 has ~3 decimal digits of precision; allow ~1% tolerance.
        for (var i = 0; i < data.Length; i++)
        {
            var original = data[i];
            var recovered = tensor[i];
            if (original == 0f)
            {
                Assert.Equal(0f, recovered);
            }
            else
            {
                var relError = Math.Abs(recovered - original) / Math.Abs(original);
                Assert.True(relError < 1e-2,
                    $"F16 round-trip drift at index {i}: original={original}, recovered={recovered}, relError={relError}");
            }
        }
    }

    [Fact]
    public void LoadTensor_BF16_DequantizesWithinTolerance()
    {
        var data = new float[] { 1f, -2f, 0.5f, 1024f, -0.0625f, 8.5f };
        var bytes = GgufTestWriter.Build(
            tensors: new[]
            {
                new GgufTestWriter.TensorEntry
                {
                    Name = "linear.weight",
                    Shape = new ulong[] { 2, 3 },
                    Type = GgufType.BF16,
                    Data = data
                }
            });

        using var loader = WriteAndOpen(bytes);
        var tensor = loader.LoadTensor("linear.weight");
        for (var i = 0; i < data.Length; i++)
        {
            Assert.Equal(data[i], tensor[i], 5);
        }
    }

    [Fact]
    public void LoadTensor_CalledTwice_ReturnsCachedInstance()
    {
        var bytes = GgufTestWriter.Build(
            tensors: new[]
            {
                new GgufTestWriter.TensorEntry
                {
                    Name = "t",
                    Shape = new ulong[] { 8 },
                    Type = GgufType.F32,
                    Data = new float[] { 1, 2, 3, 4, 5, 6, 7, 8 }
                }
            });

        using var loader = WriteAndOpen(bytes);
        var first = loader.LoadTensor("t");
        var second = loader.LoadTensor("t");
        Assert.Same(first, second);
    }

    [Fact]
    public void TryLoadTensor_AbsentTensor_ReturnsNull()
    {
        var bytes = GgufTestWriter.Build();
        using var loader = WriteAndOpen(bytes);
        Assert.Null(loader.TryLoadTensor("does.not.exist"));
    }

    [Fact]
    public void LoadTensor_AbsentTensor_Throws()
    {
        var bytes = GgufTestWriter.Build();
        using var loader = WriteAndOpen(bytes);
        Assert.Throws<KeyNotFoundException>(() => loader.LoadTensor("missing"));
    }

    [Fact]
    public void Open_WithBadMagic_Throws()
    {
        var bytes = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00 };
        var tmp = Path.GetTempFileName();
        try
        {
            File.WriteAllBytes(tmp, bytes);
            Assert.Throws<InvalidDataException>(() => GgufLoader.Open(tmp));
        }
        finally
        {
            File.Delete(tmp);
        }
    }

    [Fact]
    public void LoadTensor_Q4_0_DequantizesSyntheticBlockAgainstReference()
    {
        // Phase 2 contract: Q4_0 dequantization must match llama.cpp's reference.
        // Construct a synthetic 18-byte block with scale = 1.0 and known nibbles
        // so the recovered values are hand-checkable.
        var block = new byte[18];
        // fp16(1.0) = 0x3C00 little-endian -> bytes 0x00, 0x3C.
        block[0] = 0x00; block[1] = 0x3C;
        block[2] = 0x18;                   // qs[0]: lo=8->x=0, hi=1->x=-7
        block[3] = 0xA5;                   // qs[1]: lo=5->x=-3, hi=10->x=2
        for (var i = 4; i < 18; i++) block[i] = 0x77; // lo=hi=7 -> x=7

        var bytes = BuildMinimalHeaderWithCustomPayload(
            tensorName: "q", shape: new ulong[] { 32 },
            type: GgufType.Q4_0, payload: block);

        using var loader = WriteAndOpen(bytes);
        var tensor = loader.LoadTensor("q");

        Assert.Equal(0f, tensor[0]);    // lo qs[0]=8 -> 8-8=0
        Assert.Equal(-7f, tensor[16]);  // hi qs[0]=1 -> 1-8=-7
        Assert.Equal(-3f, tensor[1]);   // lo qs[1]=5 -> 5-8=-3
        Assert.Equal(2f, tensor[17]);   // hi qs[1]=10 -> 10-8=2
        for (var i = 2; i < 16; i++)
        {
            // qs[i] = 0x77 → lo=hi=7 → x = 7 - 8 = -1 → -1 * 1.0 = -1.
            Assert.Equal(-1f, tensor[i]);
            Assert.Equal(-1f, tensor[i + 16]);
        }
    }

    [Fact]
    public void LoadTensor_Q4_1_DequantizesSyntheticBlockAgainstReference()
    {
        // Q4_1: 2 bytes scale + 2 bytes min + 16 bytes qs = 20 bytes per block.
        // Use scale = 0.5, min = -1.0. With qs[0] = 0x18, position 0 = (8*0.5 - 1) = 3.
        var block = new byte[20];
        // fp16(0.5) = 0x3800 little-endian: 0x00, 0x38.
        block[0] = 0x00; block[1] = 0x38;
        // fp16(-1.0) = 0xBC00 little-endian: 0x00, 0xBC.
        block[2] = 0x00; block[3] = 0xBC;
        // qs[0] = 0x18: lo=8 -> x=8*0.5 + (-1) = 3, hi=1 -> x=1*0.5 + (-1) = -0.5.
        block[4] = 0x18;
        // qs[1] = 0x00: lo=0 -> -1, hi=0 -> -1.
        block[5] = 0x00;
        for (var i = 6; i < 20; i++) block[i] = 0x77; // lo=hi=7 -> x=7*0.5-1=2.5

        var bytes = BuildMinimalHeaderWithCustomPayload(
            tensorName: "q", shape: new ulong[] { 32 },
            type: GgufType.Q4_1, payload: block);

        using var loader = WriteAndOpen(bytes);
        var tensor = loader.LoadTensor("q");

        Assert.Equal(3f,    tensor[0]);
        Assert.Equal(-0.5f, tensor[16]);
        Assert.Equal(-1f,   tensor[1]);
        Assert.Equal(-1f,   tensor[17]);
        for (var i = 2; i < 16; i++)
        {
            Assert.Equal(2.5f, tensor[i]);
            Assert.Equal(2.5f, tensor[i + 16]);
        }
    }

    [Fact]
    public void LoadTensor_Q5_0_DequantizesSyntheticBlockAgainstReference()
    {
        // Q5_0: 2 bytes scale + 4 bytes qh + 16 bytes qs = 22 bytes per block.
        // Per llama.cpp: for j in 0..15, xh_0 reads bit j of qh and xh_1 reads bit j+12.
        // So we need bits 0..27 set in qh to give every weight the high bit 1.
        // qh = 0x0FFF_FFFF has only bits 0..27 — but qh >> 24 only sees bits 28..31.
        // We need qh to cover all the bits the dequantizer reads: bits 0..15 (j=0..15)
        // and bits 12..27 (j+12=12..27). So we need bits 0..27, i.e. 0x0FFF_FFFF.
        // Then for the xh_1 high bit, ((qh >> (j+12)) & 0x10) extracts bit (j+12)+4
        // of qh. For j=12, that is bit 16. For j=15, bit 19. All inside 0x0F range
        // of the low byte of qh, but ((qh >> 24) & 0x10) is bit 28 of qh.
        // 0x0FFF_FFFF has bit 28 = 0, so xh_1=0 for j=12..15. We need qh to also
        // have the bit the dequantizer extracts for those j values. To make this
        // simple, set qh to all-ones: 0xFFFFFFFF.
        var block = new byte[22];
        // fp16(1.0) little-endian = 0x00, 0x3C.
        block[0] = 0x00; block[1] = 0x3C;
        // qh = 0xFFFFFFFF little-endian = 0xFF 0xFF 0xFF 0xFF.
        block[2] = 0xFF; block[3] = 0xFF; block[4] = 0xFF; block[5] = 0xFF;
        // qs filled with 0xFF -> lo=15, hi=15. With high bit set: 15|16 = 31 -> 31-16 = 15.
        for (var i = 6; i < 22; i++) block[i] = 0xFF;

        var bytes = BuildMinimalHeaderWithCustomPayload(
            tensorName: "q", shape: new ulong[] { 32 },
            type: GgufType.Q5_0, payload: block);

        // Debug: dump payload bytes
        System.Console.Error.WriteLine($"block hex: {System.Convert.ToHexString(block)}");

        using var loader = WriteAndOpen(bytes);
        var tensor = loader.LoadTensor("q");

        // Every weight is 15 (signed 5-bit max). Times scale 1.0 = 15.
        for (var i = 0; i < 32; i++)
        {
            Assert.Equal(15f, tensor[i]);
        }
    }

    [Fact]
    public void LoadTensor_Q5_1_DequantizesSyntheticBlockAgainstReference()
    {
        // Q5_1: 2 bytes scale + 2 bytes min + 4 bytes qh + 16 bytes qs = 24 bytes per block.
        // With qh = all-ones (every high bit 1), every weight is 0x1F = 31, unsigned.
        // Output: 31 * scale + min. Pick scale = 1, min = -10, so output = 21.
        var block = new byte[24];
        // fp16(1.0) little-endian: 0x00, 0x3C.
        block[0] = 0x00; block[1] = 0x3C;
        // fp16(-10.0) = 0xC900 little-endian: 0x00, 0xC9.
        block[2] = 0x00; block[3] = 0xC9;
        // qh = 0xFFFFFFFF little-endian: 0xFF 0xFF 0xFF 0xFF.
        block[4] = 0xFF; block[5] = 0xFF; block[6] = 0xFF; block[7] = 0xFF;
        // qs = 0xFF: lo=15, hi=15. With high bit 1: x = 15 | 16 = 31.
        for (var i = 8; i < 24; i++) block[i] = 0xFF;

        var bytes = BuildMinimalHeaderWithCustomPayload(
            tensorName: "q", shape: new ulong[] { 32 },
            type: GgufType.Q5_1, payload: block);

        using var loader = WriteAndOpen(bytes);
        var tensor = loader.LoadTensor("q");

        for (var i = 0; i < 32; i++)
        {
            Assert.Equal(21f, tensor[i]);
        }
    }

    [Fact]
    public void LoadTensor_Q8_0_DequantizesSyntheticBlockAgainstReference()
    {
        // Q8_0: 4 bytes fp32 scale + 32 bytes int8 = 36 bytes per block.
        var block = new byte[36];
        // fp32(0.25) = 0x3E800000 little-endian: 0x00 0x00 0x80 0x3E.
        block[0] = 0x00; block[1] = 0x00; block[2] = 0x80; block[3] = 0x3E;
        // 32 int8 values: index i = (sbyte)(i - 16). So index 16 = 0, index 32 = 16.
        for (var i = 0; i < 32; i++)
        {
            block[4 + i] = (byte)(i - 16);
        }

        var bytes = BuildMinimalHeaderWithCustomPayload(
            tensorName: "q", shape: new ulong[] { 32 },
            type: GgufType.Q8_0, payload: block);

        using var loader = WriteAndOpen(bytes);
        var tensor = loader.LoadTensor("q");

        for (var i = 0; i < 32; i++)
        {
            Assert.Equal(0.25f * (i - 16), tensor[i]);
        }
    }

    [Fact]
    public void LoadTensor_Q6_K_RealGemma4File_MatchesLlamaCppReference()
    {
        // Q6_K is the format used for the token embedding in the real Gemma-4
        // QAT file. Skip when the file is not present so CI is unaffected.
        var path = @"C:\Users\Rene\source\repos\WebExpress.LLM\models\google\gemma-4-26b-a4b-qat\gemma-4-26B-A4B-it-QAT-Q4_0.gguf";
        if (!System.IO.File.Exists(path)) return;

        using var loader = GgufLoader.Open(path);
        var q6 = loader.Header.TensorInfos.FirstOrDefault(t => t.Type == GgufType.Q6_K);
        Assert.NotNull(q6);
        Assert.Equal("token_embd.weight", q6.Name);

        // Read 210 bytes (one Q6_K super-block) from disk via a parallel
        // FileStream to avoid loading the full ~738M-element tensor.
        var dataStart = loader.Header.TensorDataStart + (long)q6.Offset;
        var block = new byte[210];
        using (var fs = new System.IO.FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read))
        {
            fs.Position = dataStart;
            var read = 0;
            while (read < 210)
            {
                var n = fs.Read(block, read, 210 - read);
                if (n == 0) break;
                read += n;
            }
        }

        var mine = new float[256];
        GgufDequantizer.Dequantize(GgufType.Q6_K, block, mine, 256);

        // Inline llama.cpp reference transcription (dequantize_row_q6_K).
        var reference = new float[256];
        DequantizeQ6KReference(block, reference);

        for (var i = 0; i < 256; i++)
        {
            if (BitConverter.SingleToInt32Bits(mine[i]) != BitConverter.SingleToInt32Bits(reference[i]))
            {
                Assert.Fail($"Q6_K mismatch at index {i}: mine={mine[i]} (0x{BitConverter.SingleToInt32Bits(mine[i]):X8}) " +
                            $"reference={reference[i]} (0x{BitConverter.SingleToInt32Bits(reference[i]):X8})");
            }
        }
    }

    private static void DequantizeQ6KReference(byte[] data, float[] y)
    {
        // Verbatim transcription of dequantize_row_q6_K from llama.cpp. We use
        // an explicit yOffset instead of a moving pointer so we can write into
        // a caller-provided fixed-size array.
        var inPos = 0;
        var d = ReferenceHalfToFloat(BitConverter.ToUInt16(data, inPos)); inPos += 2;
        var sc = new sbyte[16];
        for (var i = 0; i < 16; i++) { sc[i] = (sbyte)data[inPos]; inPos++; }
        for (var chunk = 0; chunk < 2; chunk++)
        {
            var yOff = chunk * 128;
            var scBase = chunk * 8;
            for (var l = 0; l < 32; l++)
            {
                var subIdx = l / 16;
                var qlA = data[inPos + l];
                var qlB = data[inPos + 32 + l];
                var qh = data[inPos + 64 + l];
                var q1 = (sbyte)((qlA & 0x0F) | (((qh >> 0) & 3) << 4)) - 32;
                var q2 = (sbyte)((qlB & 0x0F) | (((qh >> 2) & 3) << 4)) - 32;
                var q3 = (sbyte)((qlA >> 4)      | (((qh >> 4) & 3) << 4)) - 32;
                var q4 = (sbyte)((qlB >> 4)      | (((qh >> 6) & 3) << 4)) - 32;
                y[yOff + l]      = d * sc[scBase + subIdx + 0] * q1;
                y[yOff + l + 32] = d * sc[scBase + subIdx + 2] * q2;
                y[yOff + l + 64] = d * sc[scBase + subIdx + 4] * q3;
                y[yOff + l + 96] = d * sc[scBase + subIdx + 6] * q4;
            }
            inPos += 64;
            inPos += 32;
        }
    }

    [Fact]
    public void LoadTensor_Q4_0_RealGemma4File_MatchesLlamaCppReference()
    {
        // Skipped when the real model file is not present so this test never
        // blocks CI. Matches the standard Gemma-4 26B-A4B QAT distribution.
        var path = @"C:\Users\Rene\source\repos\WebExpress.LLM\models\google\gemma-4-26b-a4b-qat\gemma-4-26B-A4B-it-QAT-Q4_0.gguf";
        if (!System.IO.File.Exists(path)) return;

        using var loader = GgufLoader.Open(path);
        var q4 = loader.Header.TensorInfos.FirstOrDefault(t => t.Type == GgufType.Q4_0);
        Assert.NotNull(q4);

        // Read 18 bytes directly via a parallel FileStream to avoid loading the
        // full multi-megabyte tensor into memory during a unit test.
        var dataStart = loader.Header.TensorDataStart + (long)q4.Offset;
        var block = new byte[18];
        using (var fs = new System.IO.FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read))
        {
            fs.Position = dataStart;
            var read = 0;
            while (read < 18)
            {
                var n = fs.Read(block, read, 18 - read);
                if (n == 0) break;
                read += n;
            }
        }

        var mine = new float[32];
        GgufDequantizer.Dequantize(GgufType.Q4_0, block, mine, 32);

        // Inline llama.cpp reference transcription (dequantize_row_q4_0).
        var d = ReferenceHalfToFloat(BitConverter.ToUInt16(block, 0));
        for (var j = 0; j < 16; j++)
        {
            var packed = block[2 + j];
            var x0 = (packed & 0x0F) - 8;
            var x1 = (packed >> 4) - 8;
            Assert.Equal(x0 * d, mine[j]);
            Assert.Equal(x1 * d, mine[j + 16]);
        }
    }

    private static float ReferenceHalfToFloat(ushort bits)
    {
        var sign = (bits >> 15) & 0x1;
        var exp = (bits >> 10) & 0x1F;
        var mant = bits & 0x3FF;
        if (exp == 0)
        {
            if (mant == 0) return sign == 0 ? 0f : -0f;
            var e = -14;
            while ((mant & 0x400) == 0) { mant <<= 1; e--; }
            mant &= 0x3FF;
            var f32Exp = (uint)(e + 127);
            var f32Bits = ((uint)sign << 31) | (f32Exp << 23) | ((uint)mant << 13);
            return BitConverter.Int32BitsToSingle(unchecked((int)f32Bits));
        }
        if (exp == 31)
        {
            if (mant == 0) return sign == 0 ? float.PositiveInfinity : float.NegativeInfinity;
            var f32Bits = ((uint)sign << 31) | (0xFFu << 23) | ((uint)mant << 13);
            return BitConverter.Int32BitsToSingle(unchecked((int)f32Bits));
        }
        var newExp = (uint)(exp - 15 + 127);
        var f32Bits2 = ((uint)sign << 31) | (newExp << 23) | ((uint)mant << 13);
        return BitConverter.Int32BitsToSingle(unchecked((int)f32Bits2));
    }

    /// <summary>
    /// Build a GGUF file with arbitrary payload bytes for tensors whose format
    /// the writer does not know how to synthesize. The tensor info and offsets
    /// are correct; only the payload content is opaque.
    /// </summary>
    private static byte[] BuildMinimalHeaderWithCustomPayload(
        string tensorName,
        ulong[] shape,
        GgufType type,
        byte[] payload)
    {
        using var ms = new MemoryStream();
        using (var w = new BinaryWriter(ms, System.Text.Encoding.UTF8, leaveOpen: true))
        {
            w.Write(GgufHeader.Magic);
            w.Write((uint)3);
            w.Write((ulong)1);
            w.Write((ulong)0);

            var nameBytes = System.Text.Encoding.UTF8.GetBytes(tensorName);
            w.Write((ulong)nameBytes.Length);
            w.Write(nameBytes);
            w.Write((uint)shape.Length);
            foreach (var d in shape) w.Write(d);
            w.Write((uint)type);
            w.Write((ulong)0); // offset patched below

            // Align to 32
            while (ms.Position % 32 != 0) w.Write((byte)0);

            var dataStart = ms.Position;
            long offsetFieldPos = 24 + 8 + nameBytes.Length + 4 + 8 * shape.Length + 4;
            var savedPos = ms.Position;
            ms.Position = offsetFieldPos;
            w.Write((ulong)0);
            ms.Position = savedPos;

            w.Write(payload);
        }
        return ms.ToArray();
    }

    private static GgufLoader WriteAndOpen(byte[] bytes)
    {
        var tmp = Path.GetTempFileName();
        File.WriteAllBytes(tmp, bytes);
        return GgufLoader.Open(tmp);
    }
}