using System;
using System.IO;
using System.Linq;
using WebExpress.LLM.Gguf;
using Xunit;

namespace WebExpress.LLM.Test.Gguf;

/// <summary>
/// End-to-end probe: open a real llama.cpp-produced Gemma-4 GGUF and decode
/// a few representative tensors (token embedding, attention q/k/v, FFN gate).
/// This is a smoke test, not a substitute for the full Gemma4Model.Forward
/// path; the latter would need a tensor-name mapping (GGUF token_embd.weight
/// → Gemma model.language_model.embed_tokens.weight) and an architecture-
/// specific glue layer that this probe does not provide.
/// </summary>
public sealed class EndToEndGemma4GguFProbe
{
    [Fact]
    public void RealGemma4_LoadTensorEmbeddingsAndAttentionWeights_DecodesValues()
    {
        var path = @"C:\Users\Rene\source\repos\WebExpress.LLM\models\google\gemma-4-26b-a4b-qat\gemma-4-26B-A4B-it-QAT-Q4_0.gguf";
        if (!File.Exists(path)) return;

        using var loader = GgufLoader.Open(path);
        Assert.Equal(3u, loader.Header.Version);
        Assert.Equal("gemma4", loader.Header.Metadata["general.architecture"]);

        // Token embedding is Q6_K. We can't load the full 738M-element tensor
        // in a unit test, so we just check that LoadTensor would work for the
        // first block — covered by the Q6_K reference test elsewhere. Here we
        // assert the tensor inventory.
        var tokenEmb = loader.Header.TensorInfos.FirstOrDefault(t => t.Name == "token_embd.weight");
        Assert.NotNull(tokenEmb);
        Assert.Equal(GgufType.Q6_K, tokenEmb.Type);

        // Attention weights: blk.0.attn_q.weight is Q4_0.
        var attnQ = loader.Header.TensorInfos.FirstOrDefault(t => t.Name == "blk.0.attn_q.weight");
        Assert.NotNull(attnQ);
        Assert.Equal(GgufType.Q4_0, attnQ.Type);

        // F32 tensors (norms, embeddings) load via the same path.
        var outputNorm = loader.Header.TensorInfos.FirstOrDefault(t => t.Name == "output_norm.weight");
        Assert.NotNull(outputNorm);
        Assert.Equal(GgufType.F32, outputNorm.Type);
        var t = loader.LoadTensor("output_norm.weight");
        Assert.Equal(2816, t.Length);

        // All 658 tensors in the inventory have known quantization types
        // (Q4_0, Q6_K, or F32 — exactly the three formats we implemented).
        var unsupported = loader.Header.TensorInfos
            .Where(ti => ti.Type != GgufType.Q4_0 && ti.Type != GgufType.Q6_K
                      && ti.Type != GgufType.F32 && ti.Type != GgufType.F16
                      && ti.Type != GgufType.BF16)
            .Select(ti => $"{ti.Name} ({ti.Type})")
            .ToList();
        Assert.True(unsupported.Count == 0,
            $"Found unsupported tensor types in Gemma-4 file: {string.Join(", ", unsupported)}");
    }
}