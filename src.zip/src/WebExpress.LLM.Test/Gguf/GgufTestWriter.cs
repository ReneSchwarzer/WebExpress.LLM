using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Text;
using WebExpress.LLM.Gguf;

namespace WebExpress.LLM.Test.Gguf;

/// <summary>
/// Minimal in-memory GGUF writer for unit tests. Produces a binary GGUF v3
/// file containing one or more tensors with F32, F16, or BF16 payloads, plus
/// an arbitrary set of metadata KV pairs. Round-trips through <see cref="GgufLoader"/>.
///
/// Phase 1 covers only unquantized types because the writer needs to know the
/// block layout for each quantized scheme it produces. Phase 2 (legacy k-quants)
/// would extend this with Q4_0/Q4_1/Q5_0/Q5_1/Q8_0 writers — left out for now
/// because every quantized writer must be paired with a verifiable reference
/// (e.g. llama.cpp's <c>quantize</c> tool) before the round-trip tests are
/// trustworthy.
/// </summary>
internal static class GgufTestWriter
{
    public sealed class TensorEntry
    {
        public string Name { get; init; } = "";
        public ulong[] Shape { get; init; } = Array.Empty<ulong>();
        public GgufType Type { get; init; }
        public float[] Data { get; init; } = Array.Empty<float>();
    }

    public sealed class MetadataEntry
    {
        public string Key { get; init; } = "";
        public object Value { get; init; } = "";
    }

    public static byte[] Build(
        IReadOnlyList<MetadataEntry>? metadata = null,
        IReadOnlyList<TensorEntry>? tensors = null,
        uint alignment = 32)
    {
        if (alignment == 0 || (alignment & (alignment - 1)) != 0)
        {
            throw new ArgumentException("Alignment must be a power of two.", nameof(alignment));
        }

        metadata ??= Array.Empty<MetadataEntry>();
        tensors ??= Array.Empty<TensorEntry>();

        // Ensure general.alignment is present in metadata.
        var hasAlignment = false;
        foreach (var kv in metadata)
        {
            if (kv.Key == "general.alignment") { hasAlignment = true; break; }
        }
        if (!hasAlignment)
        {
            var copy = new List<MetadataEntry>(metadata) { new() { Key = "general.alignment", Value = alignment } };
            metadata = copy;
        }

        using var ms = new MemoryStream();
        using (var writer = new BinaryWriter(ms, Encoding.UTF8, leaveOpen: true))
        {
            // Header
            writer.Write(GgufHeader.Magic);
            writer.Write((uint)3);
            writer.Write((ulong)tensors.Count);
            writer.Write((ulong)metadata.Count);

            foreach (var kv in metadata)
            {
                WriteMetadataKv(writer, kv.Key, kv.Value);
            }

            // Tensor infos — placeholder offsets are patched after we know
            // alignment-padded layout.
            long tensorInfoBase = writer.BaseStream.Position;
            foreach (var t in tensors)
            {
                WriteTensorInfo(writer, t, offset: 0);
            }

            ulong dataStart = AlignUp((ulong)writer.BaseStream.Position, alignment);
            while ((ulong)writer.BaseStream.Position < dataStart)
            {
                writer.Write((byte)0);
            }

            ulong cursor = dataStart;
            for (var i = 0; i < tensors.Count; i++)
            {
                var t = tensors[i];
                var payloadSize = PayloadSize(t);

                long infoOffsetFieldPos = tensorInfoBase;
                for (var j = 0; j < i; j++)
                {
                    infoOffsetFieldPos += TensorInfoSize(tensors[j]);
                }
                infoOffsetFieldPos += TensorInfoSize(t) - 8;

                // GGUF spec: Offset is relative to tensor_data (= dataStart).
                PatchUInt64(writer, infoOffsetFieldPos, cursor - dataStart);

                while ((ulong)writer.BaseStream.Position < cursor)
                {
                    writer.Write((byte)0);
                }

                WriteTensorPayload(writer, t);

                cursor = AlignUp(cursor + payloadSize, alignment);
            }

            while ((ulong)writer.BaseStream.Position % alignment != 0)
            {
                writer.Write((byte)0);
            }
        }

        return ms.ToArray();
    }

    private static long TensorInfoSize(TensorEntry t)
    {
        var nameBytes = Encoding.UTF8.GetByteCount(t.Name);
        return 8 + nameBytes + 4 + 8 * t.Shape.Length + 4 + 8;
    }

    private static ulong PayloadSize(TensorEntry t)
    {
        return (ulong)t.Data.Length * (t.Type switch
        {
            GgufType.F32  => 4,
            GgufType.F16  => 2,
            GgufType.BF16 => 2,
            _ => throw new NotSupportedException(
                $"GgufTestWriter cannot size type {t.Type}; extend PayloadSize when adding support."),
        });
    }

    private static void PatchUInt64(BinaryWriter writer, long position, ulong value)
    {
        var saved = writer.BaseStream.Position;
        writer.BaseStream.Position = position;
        writer.Write(value);
        writer.BaseStream.Position = saved;
    }

    private static void WriteTensorInfo(BinaryWriter writer, TensorEntry t, ulong offset)
    {
        var nameBytes = Encoding.UTF8.GetBytes(t.Name);
        writer.Write((ulong)nameBytes.Length);
        writer.Write(nameBytes);
        writer.Write((uint)t.Shape.Length);
        foreach (var d in t.Shape) writer.Write(d);
        writer.Write((uint)t.Type);
        writer.Write(offset);
    }

    private static void WriteTensorPayload(BinaryWriter writer, TensorEntry t)
    {
        switch (t.Type)
        {
            case GgufType.F32:
                for (var i = 0; i < t.Data.Length; i++) writer.Write(t.Data[i]);
                break;
            case GgufType.F16:
                for (var i = 0; i < t.Data.Length; i++) writer.Write(FloatToHalf(t.Data[i]));
                break;
            case GgufType.BF16:
                for (var i = 0; i < t.Data.Length; i++)
                {
                    var f = t.Data[i];
                    var bits = BitConverter.SingleToInt32Bits(f);
                    writer.Write((ushort)(bits >> 16));
                }
                break;
            default:
                throw new NotSupportedException(
                    $"GgufTestWriter does not know how to serialize type {t.Type}.");
        }
    }

    private static ulong AlignUp(ulong value, uint alignment)
    {
        var rem = value % alignment;
        return rem == 0 ? value : value + (alignment - rem);
    }

    private static void WriteMetadataKv(BinaryWriter writer, string key, object value)
    {
        var keyBytes = Encoding.UTF8.GetBytes(key);
        writer.Write((ulong)keyBytes.Length);
        writer.Write(keyBytes);
        WriteMetadataValue(writer, value);
    }

    private static void WriteMetadataValue(BinaryWriter writer, object value)
    {
        switch (value)
        {
            case byte b:
                writer.Write((uint)GgufMetadataValueType.UInt8); writer.Write(b); break;
            case sbyte sb:
                writer.Write((uint)GgufMetadataValueType.Int8); writer.Write(sb); break;
            case ushort us:
                writer.Write((uint)GgufMetadataValueType.UInt16); writer.Write(us); break;
            case short ss:
                writer.Write((uint)GgufMetadataValueType.Int16); writer.Write(ss); break;
            case uint ui:
                writer.Write((uint)GgufMetadataValueType.UInt32); writer.Write(ui); break;
            case int si:
                writer.Write((uint)GgufMetadataValueType.Int32); writer.Write(si); break;
            case float f:
                writer.Write((uint)GgufMetadataValueType.Float32); writer.Write(f); break;
            case bool bo:
                writer.Write((uint)GgufMetadataValueType.Bool); writer.Write(bo ? (byte)1 : (byte)0); break;
            case string s:
                writer.Write((uint)GgufMetadataValueType.String);
                var sb2 = Encoding.UTF8.GetBytes(s);
                writer.Write((ulong)sb2.Length);
                writer.Write(sb2);
                break;
            case ulong ul:
                writer.Write((uint)GgufMetadataValueType.UInt64); writer.Write(ul); break;
            case long sl:
                writer.Write((uint)GgufMetadataValueType.Int64); writer.Write(sl); break;
            case double d:
                writer.Write((uint)GgufMetadataValueType.Float64); writer.Write(d); break;
            case object[] arr:
                writer.Write((uint)GgufMetadataValueType.Array);
                writer.Write((uint)ArrayElementType(arr));
                writer.Write((ulong)arr.Length);
                foreach (var item in arr) WriteMetadataValue(writer, item);
                break;
            default:
                throw new NotSupportedException(
                    $"GgufTestWriter cannot serialize metadata value of type {value.GetType()}.");
        }
    }

    private static GgufMetadataValueType ArrayElementType(object[] arr)
    {
        if (arr.Length == 0) return GgufMetadataValueType.String;
        return arr[0] switch
        {
            byte => GgufMetadataValueType.UInt8,
            sbyte => GgufMetadataValueType.Int8,
            ushort => GgufMetadataValueType.UInt16,
            short => GgufMetadataValueType.Int16,
            uint => GgufMetadataValueType.UInt32,
            int => GgufMetadataValueType.Int32,
            float => GgufMetadataValueType.Float32,
            bool => GgufMetadataValueType.Bool,
            string => GgufMetadataValueType.String,
            ulong => GgufMetadataValueType.UInt64,
            long => GgufMetadataValueType.Int64,
            double => GgufMetadataValueType.Float64,
            _ => throw new NotSupportedException(
                $"GgufTestWriter cannot infer array element type for {arr[0].GetType()}."),
        };
    }

    /// <summary>IEEE-754 binary32 to binary16 (RTNE rounding).</summary>
    public static ushort FloatToHalf(float value)
    {
        var bits = BitConverter.SingleToInt32Bits(value);
        var sign = (bits >> 16) & 0x8000;
        var v = bits & 0x7FFFFFFF;

        if (v >= 0x7F800000)
        {
            var mant = v == 0x7F800000 ? 0 : (v & 0x007FFFFF) >> 13;
            return (ushort)(sign | 0x7C00 | mant);
        }
        if (v <= 0x38800000)
        {
            var mant = v < 0x33000000 ? 0 : (((v - 0x38000000) >> 13) + 1) & 0x3FF;
            return (ushort)(sign | mant);
        }

        var exp = ((v >> 23) - 127 + 15) & 0x1F;
        var m = (v >> 13) & 0x3FF;
        return (ushort)(sign | (exp << 10) | m);
    }
}