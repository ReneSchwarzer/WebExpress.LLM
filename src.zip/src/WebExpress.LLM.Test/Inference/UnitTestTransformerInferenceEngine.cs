using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebExpress.LLM.Inference;
using WebExpress.LLM.Model;

namespace WebExpress.LLM.Test.Inference;

/// <summary>
/// Provides unit tests for the TransformerInferenceEngine class.
/// </summary>
public sealed class UnitTestTransformerInferenceEngine
{
    [Fact]
    public void GenerateTokens_FallbackMode_ShouldWorkAndBeDeterministic()
    {
        var config = new ModelConfiguration
        {
            VocabularySize = 256,
            ContextLength = 128,
            HiddenSize = 64,
            NumberOfLayers = 2,
            NumberOfAttentionHeads = 2,
            NumberOfKeyValueHeads = 1,
            HeadDimension = 8
        };

        var modelDef = new ModelDefinition
        {
            Configuration = config
        };

        var samplingStrategy = new GreedySampling();
        var engine = new TransformerInferenceEngine(modelDef, samplingStrategy);

        var prompt = new[] { 10, 20, 30 };
        var firstResult = engine.GenerateTokens(prompt, 5);
        var secondResult = engine.GenerateTokens(prompt, 5);

        Assert.Equal(5, firstResult.Count);
        Assert.Equal(firstResult, secondResult);
    }

    [Fact]
    public async Task GenerateTokensAsync_FallbackMode_ShouldWorkAndBeDeterministic()
    {
        var config = new ModelConfiguration
        {
            VocabularySize = 256,
            ContextLength = 128,
            HiddenSize = 64,
            NumberOfLayers = 2,
            NumberOfAttentionHeads = 2,
            NumberOfKeyValueHeads = 1,
            HeadDimension = 8
        };

        var modelDef = new ModelDefinition
        {
            Configuration = config
        };

        var samplingStrategy = new GreedySampling();
        var engine = new TransformerInferenceEngine(modelDef, samplingStrategy);

        var prompt = new[] { 10, 20, 30 };
        var firstResult = new List<int>();
        await foreach (var token in engine.GenerateTokensAsync(prompt, 5))
        {
            firstResult.Add(token);
        }

        var secondResult = new List<int>();
        await foreach (var token in engine.GenerateTokensAsync(prompt, 5))
        {
            secondResult.Add(token);
        }

        Assert.Equal(5, firstResult.Count);
        Assert.Equal(firstResult, secondResult);
    }

    /// <summary>
    /// Verifies that the async streaming generator stops immediately on an EOS token
    /// and does not yield the EOS token to the caller. Regression test for the
    /// missing EOS-break in GenerateTokensAsync, which caused the console chat to
    /// emit the Gemma-4 end-of-turn marker <c>&lt;turn|&gt;</c> multiple times
    /// instead of stopping after the first occurrence.
    /// </summary>
    [Fact]
    public async Task GenerateTokensAsync_ShouldStopOnEosAndNotYieldIt()
    {
        var config = new ModelConfiguration
        {
            VocabularySize = 256,
            ContextLength = 128,
            HiddenSize = 64,
            NumberOfLayers = 1,
            NumberOfAttentionHeads = 1,
            NumberOfKeyValueHeads = 1,
            HeadDimension = 8,
            EosTokenIds = new[] { 7 }
        };

        var modelDef = new ModelDefinition { Configuration = config };

        // Custom sampling strategy: always sample token 7 (which is EOS).
        // Before the fix this looped up to maxNewTokens; with the fix it stops
        // at the first iteration.
        var eosFirstSampling = new EosFirstSamplingStrategy(token: 7);
        var engine = new TransformerInferenceEngine(modelDef, eosFirstSampling);

        var prompt = new[] { 1, 2, 3 };
        var yielded = new List<int>();
        await foreach (var token in engine.GenerateTokensAsync(prompt, maxNewTokens: 50))
        {
            yielded.Add(token);
        }

        // EOS must NOT appear in the yielded stream — the engine stops before yielding it.
        Assert.DoesNotContain(7, yielded);
        // And the generator must stop immediately, not run for the full 50-token budget.
        Assert.Empty(yielded);
    }

    /// <summary>
    /// Test-only sampling strategy that always returns the configured token id.
    /// </summary>
    private sealed class EosFirstSamplingStrategy : ISamplingStrategy
    {
        private readonly int _token;
        public EosFirstSamplingStrategy(int token) { _token = token; }
        public int Sample(System.Collections.Generic.IReadOnlyList<float> logits,
                          System.Collections.Generic.IReadOnlyList<int> contextTokens)
        {
            return _token;
        }
    }
}
