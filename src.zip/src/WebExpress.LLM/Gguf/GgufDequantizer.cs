using System;
using System.Buffers.Binary;

namespace WebExpress.LLM.Gguf;

/// <summary>
/// Dequantizes GGUF tensor data into <c>float[]</c>. Each <see cref="GgufType"/>
/// has a fixed block layout — see the GGUF v3 spec and llama.cpp's
/// <c>ggml-quants.c</c> for authoritative byte layouts.
///
/// Phase 1: F32, F16, BF16 (element-wise, exact or near-exact precision).
/// Quantized block types (Q4_0 through Q8_1 and k-quants / i-quants) will throw
/// <see cref="NotSupportedException"/> until those phases are implemented and
/// independently verified against a reference such as llama.cpp's quantize tool.
/// </summary>
public static class GgufDequantizer
{
    /// <summary>
    /// Decode a quantized tensor block (or full F32/F16/BF16 tensor) into
    /// <paramref name="output"/>. The output buffer must be sized to
    /// <c>tensor.ElementCount</c> floats.
    /// </summary>
    public static void Dequantize(
        GgufType type,
        ReadOnlySpan<byte> data,
        Span<float> output,
        ulong elementCount)
    {
        switch (type)
        {
            case GgufType.F32:
                DequantizeF32(data, output, elementCount);
                break;
            case GgufType.F16:
                DequantizeF16(data, output, elementCount);
                break;
            case GgufType.BF16:
                DequantizeBF16(data, output, elementCount);
                break;
            case GgufType.Q4_0:
                DequantizeQ40(data, output, elementCount);
                break;
            case GgufType.Q4_1:
                DequantizeQ41(data, output, elementCount);
                break;
            case GgufType.Q5_0:
                DequantizeQ50(data, output, elementCount);
                break;
            case GgufType.Q5_1:
                DequantizeQ51(data, output, elementCount);
                break;
            case GgufType.Q8_0:
                DequantizeQ80(data, output, elementCount);
                break;
            case GgufType.Q6_K:
                DequantizeQ6K(data, output, elementCount);
                break;
            default:
                throw new NotSupportedException(
                    $"GGUF dequantization for type {type} is not implemented in this build. " +
                    $"Add the dequantizer in GgufDequantizer.cs or pre-dequantize the file with llama.cpp's convert tool.");
        }
    }

    /// <summary>
    /// Dequantize one Q4_0 block: <c>[fp16 scale | 32 × uint4 nibbles]</c>.
    /// Layout per llama.cpp <c>dequantize_row_q4_0</c>:
    /// nibble <c>j</c>'s lo half encodes position <c>j</c>; hi half encodes position <c>j+16</c>.
    /// </summary>
    private static void DequantizeQ40(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        var blocks = NumBlocks(elementCount, 32);
        var required = (ulong)blocks * 18UL;
        if ((ulong)data.Length < required)
        {
            throw new ArgumentException(
                $"Q4_0 payload size {data.Length} is smaller than expected {required} bytes.");
        }

        var pos = 0;
        var blockOutBase = 0;
        for (var b = 0; b < blocks; b++)
        {
            var d = HalfToFloat(BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(pos, 2)));
            pos += 2;
            for (var j = 0; j < 16; j++)
            {
                var packed = data[pos + j];
                var x0 = (packed & 0x0F) - 8;
                var x1 = (packed >> 4) - 8;
                output[blockOutBase + j]      = x0 * d;
                output[blockOutBase + j + 16] = x1 * d;
            }
            pos += 16;
            blockOutBase += 32;
        }
    }

    /// <summary>
    /// Dequantize one Q4_1 block: <c>[fp16 scale | fp16 min | 32 × uint4 nibbles]</c>.
    /// Per llama.cpp: nibbles are unsigned, output is <c>lo*d + m</c> / <c>hi*d + m</c>.
    /// </summary>
    private static void DequantizeQ41(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        var blocks = NumBlocks(elementCount, 32);
        var required = (ulong)blocks * 20UL;
        if ((ulong)data.Length < required)
        {
            throw new ArgumentException(
                $"Q4_1 payload size {data.Length} is smaller than expected {required} bytes.");
        }

        var pos = 0;
        var blockOutBase = 0;
        for (var b = 0; b < blocks; b++)
        {
            var d = HalfToFloat(BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(pos, 2)));
            var m = HalfToFloat(BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(pos + 2, 2)));
            pos += 4;
            for (var j = 0; j < 16; j++)
            {
                var packed = data[pos + j];
                var x0 = packed & 0x0F;
                var x1 = packed >> 4;
                output[blockOutBase + j]      = x0 * d + m;
                output[blockOutBase + j + 16] = x1 * d + m;
            }
            pos += 16;
            blockOutBase += 32;
        }
    }

    /// <summary>
    /// Dequantize one Q5_0 block: <c>[fp16 scale | 4 bytes qh | 16 bytes qs]</c>.
    /// 5-bit signed values from low 4 bits of qs + high bit from qh. Layout per
    /// llama.cpp <c>dequantize_row_q5_0</c>: bit <c>j</c> in qh supplies the high
    /// bit for the low-nibble value at position <c>j</c>; bit <c>j+12</c> does
    /// the same for the high-nibble value at position <c>j+16</c>.
    /// </summary>
    private static void DequantizeQ50(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        var blocks = NumBlocks(elementCount, 32);
        var required = (ulong)blocks * 22UL;
        if ((ulong)data.Length < required)
        {
            throw new ArgumentException(
                $"Q5_0 payload size {data.Length} is smaller than expected {required} bytes.");
        }

        var pos = 0;
        var blockOutBase = 0;
        for (var b = 0; b < blocks; b++)
        {
            var d = HalfToFloat(BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(pos, 2)));
            pos += 2;
            var qh = BinaryPrimitives.ReadUInt32LittleEndian(data.Slice(pos, 4));
            pos += 4;
            for (var j = 0; j < 16; j++)
            {
                var packed = data[pos + j];
                var xh0 = (byte)(((qh >> (j + 0)) << 4) & 0x10);
                var xh1 = (byte)(((qh >> (j + 12))    ) & 0x10);
                var x0 = ((packed & 0x0F) | xh0) - 16;
                var x1 = ((packed >> 4) | xh1) - 16;
                output[blockOutBase + j]      = x0 * d;
                output[blockOutBase + j + 16] = x1 * d;
            }
            pos += 16;
            blockOutBase += 32;
        }
    }

    /// <summary>
    /// Dequantize one Q5_1 block: <c>[fp16 scale | fp16 min | 4 bytes qh | 16 bytes qs]</c>.
    /// Same high-bit layout as Q5_0 but nibbles are unsigned and the output is
    /// <c>x*d + m</c> (with no -8 offset). Layout per llama.cpp <c>dequantize_row_q5_1</c>.
    /// </summary>
    private static void DequantizeQ51(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        var blocks = NumBlocks(elementCount, 32);
        var required = (ulong)blocks * 24UL;
        if ((ulong)data.Length < required)
        {
            throw new ArgumentException(
                $"Q5_1 payload size {data.Length} is smaller than expected {required} bytes.");
        }

        var pos = 0;
        var blockOutBase = 0;
        for (var b = 0; b < blocks; b++)
        {
            var d = HalfToFloat(BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(pos, 2)));
            var m = HalfToFloat(BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(pos + 2, 2)));
            pos += 4;
            var qh = BinaryPrimitives.ReadUInt32LittleEndian(data.Slice(pos, 4));
            pos += 4;
            for (var j = 0; j < 16; j++)
            {
                var packed = data[pos + j];
                var xh0 = (byte)(((qh >> (j + 0)) << 4) & 0x10);
                var xh1 = (byte)(((qh >> (j + 12))    ) & 0x10);
                var x0 = (packed & 0x0F) | xh0;
                var x1 = (packed >> 4) | xh1;
                output[blockOutBase + j]      = x0 * d + m;
                output[blockOutBase + j + 16] = x1 * d + m;
            }
            pos += 16;
            blockOutBase += 32;
        }
    }

    /// <summary>
    /// Dequantize one Q8_0 block: <c>[fp32 scale | 32 × int8 weights]</c>. Linear,
    /// no packing. Layout per llama.cpp <c>dequantize_row_q8_0</c>.
    /// </summary>
    private static void DequantizeQ80(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        var blocks = NumBlocks(elementCount, 32);
        var required = (ulong)blocks * 36UL;
        if ((ulong)data.Length < required)
        {
            throw new ArgumentException(
                $"Q8_0 payload size {data.Length} is smaller than expected {required} bytes.");
        }

        var pos = 0;
        var blockOutBase = 0;
        for (var b = 0; b < blocks; b++)
        {
            var d = BinaryPrimitives.ReadSingleLittleEndian(data.Slice(pos, 4));
            pos += 4;
            for (var j = 0; j < 32; j++)
            {
                output[blockOutBase + j] = d * (sbyte)data[pos + j];
            }
            pos += 32;
            blockOutBase += 32;
        }
    }

    /// <summary>
    /// Dequantize one Q6_K super-block (256 elements). Layout per llama.cpp
    /// <c>dequantize_row_q6_K</c>:
    /// <c>[fp16 d | 16 × int8 scales | 128 × 4-bit low weights | 64 × 2-bit high weights]</c>.
    /// 6-bit weight is reconstructed as <c>(ql_lo | (qh &lt;&lt; 4)) - 32</c> (signed).
    /// </summary>
    private static void DequantizeQ6K(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        // 210 bytes per super-block of 256 elements.
        const int BlockSize = 256;
        const int BytesPerBlock = 210;
        var blocks = NumBlocks(elementCount, BlockSize);
        var required = (ulong)blocks * (ulong)BytesPerBlock;
        if ((ulong)data.Length < required)
        {
            throw new ArgumentException(
                $"Q6_K payload size {data.Length} is smaller than expected {required} bytes.");
        }

        // Hoisted out of the per-block loop: a single stack slot reused across
        // every super-block. Avoids per-block stackalloc bookkeeping and keeps
        // the JIT code trivial.
        Span<sbyte> scales = stackalloc sbyte[16];

        var inPos = 0;
        var outPos = 0;
        for (var b = 0; b < blocks; b++)
        {
            var d = HalfToFloat(BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(inPos, 2)));
            inPos += 2;
            for (var i = 0; i < 16; i++) scales[i] = (sbyte)data[inPos + i];
            inPos += 16;
            // 128 bytes ql (low 4 bits) and 64 bytes qh (high 2 bits), in 128-element
            // chunks. Each 128-element chunk contains 4 sub-blocks of 16 elements each,
            // and the inner loop walks them in 32-iteration steps that produce 4 outputs
            // per iteration (one for each of the 4 sub-blocks).
            // Each chunk uses 8 consecutive scale slots: chunk 0 -> [0..7], chunk 1 -> [8..15].
            for (var chunk = 0; chunk < 2; chunk++)
            {
                var scBase = chunk * 8;
                for (var l = 0; l < 32; l++)
                {
                    var subIdx = l / 16;
                    var ql_a = data[inPos + l];
                    var ql_b = data[inPos + 32 + l];
                    var qh_byte = data[inPos + 64 + l];
                    var q1 = (sbyte)((ql_a & 0x0F) | (((qh_byte >> 0) & 3) << 4)) - 32;
                    var q2 = (sbyte)((ql_b & 0x0F) | (((qh_byte >> 2) & 3) << 4)) - 32;
                    var q3 = (sbyte)((ql_a >> 4)      | (((qh_byte >> 4) & 3) << 4)) - 32;
                    var q4 = (sbyte)((ql_b >> 4)      | (((qh_byte >> 6) & 3) << 4)) - 32;
                    output[outPos + l]      = d * scales[scBase + subIdx + 0] * q1;
                    output[outPos + l + 32] = d * scales[scBase + subIdx + 2] * q2;
                    output[outPos + l + 64] = d * scales[scBase + subIdx + 4] * q3;
                    output[outPos + l + 96] = d * scales[scBase + subIdx + 6] * q4;
                }
                outPos += 128;
                inPos += 64; // 32 bytes ql_a + 32 bytes ql_b
                inPos += 32; // 32 bytes qh
            }
            // Reset scales offset for the next super-block: scales is local.
        }
    }

    /// <summary>Whole blocks required to store <paramref name="elementCount"/> elements of <paramref name="blockSize"/>.</summary>
    private static int NumBlocks(ulong elementCount, int blockSize)
    {
        return (int)((elementCount + (ulong)(blockSize - 1)) / (ulong)blockSize);
    }

    /// <summary>Number of bytes that <paramref name="type"/> consumes for one logical element count.</summary>
    public static ulong ByteSize(GgufType type, ulong elementCount)
    {
        // Q4_0: 32-element blocks, 2 bytes fp16 scale + 16 bytes nibbles = 18 bytes per block.
        var blocks = (ulong)((elementCount + 31UL) / 32UL);
        return type switch
        {
            GgufType.F32  => elementCount * 4,
            GgufType.F16  => elementCount * 2,
            GgufType.BF16 => elementCount * 2,
            GgufType.Q4_0 => blocks * 18,
            GgufType.Q4_1 => blocks * 20,
            GgufType.Q5_0 => blocks * 22,
            GgufType.Q5_1 => blocks * 24,
            GgufType.Q8_0 => blocks * 36,
            // Q6_K uses 256-element super-blocks; 210 bytes each. For mixed element
            // counts we still need whole super-blocks, so the same conservative
            // block-rounding applies.
            GgufType.Q6_K => ((elementCount + 255UL) / 256UL) * 210UL,
            _ => throw new NotSupportedException($"ByteSize not implemented for {type}; use the full dequantize path."),
        };
    }

    private static void DequantizeF32(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        if ((ulong)data.Length < elementCount * 4)
        {
            throw new ArgumentException(
                $"F32 payload size {data.Length} is smaller than expected {elementCount * 4} bytes.");
        }

        for (var i = 0; i < (int)elementCount; i++)
        {
            output[i] = BinaryPrimitives.ReadSingleLittleEndian(data.Slice(i * 4, 4));
        }
    }

    private static void DequantizeF16(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        if ((ulong)data.Length < elementCount * 2)
        {
            throw new ArgumentException(
                $"F16 payload size {data.Length} is smaller than expected {elementCount * 2} bytes.");
        }

        for (var i = 0; i < (int)elementCount; i++)
        {
            var bits = BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(i * 2, 2));
            output[i] = HalfToFloat(bits);
        }
    }

    private static void DequantizeBF16(ReadOnlySpan<byte> data, Span<float> output, ulong elementCount)
    {
        if ((ulong)data.Length < elementCount * 2)
        {
            throw new ArgumentException(
                $"BF16 payload size {data.Length} is smaller than expected {elementCount * 2} bytes.");
        }

        // bfloat16 is the upper 16 bits of an IEEE-754 float32 (same exponent
        // and mantissa width, just truncated precision). Promoting it to float32
        // is a left-shift by 16 on the bit pattern — no exponent re-biasing.
        for (var i = 0; i < (int)elementCount; i++)
        {
            var bf16 = BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(i * 2, 2));
            var f32Bits = (uint)bf16 << 16;
            output[i] = BitConverter.Int32BitsToSingle(unchecked((int)f32Bits));
        }
    }

    /// <summary>
    /// IEEE-754 binary16 to binary32 conversion. Reference implementation —
    /// handles zero, subnormal, normal, infinity, and NaN inputs.
    /// </summary>
    private static float HalfToFloat(ushort bits)
    {
        var sign = (bits >> 15) & 0x1;
        var exp = (bits >> 10) & 0x1F;
        var mant = bits & 0x3FF;

        if (exp == 0)
        {
            if (mant == 0)
            {
                return sign == 0 ? 0f : -0f;
            }
            var e = -14;
            while ((mant & 0x400) == 0)
            {
                mant <<= 1;
                e--;
            }
            mant &= 0x3FF;
            var f32Exp = (uint)(e + 127);
            var f32Bits = ((uint)sign << 31) | (f32Exp << 23) | ((uint)mant << 13);
            return BitConverter.Int32BitsToSingle(unchecked((int)f32Bits));
        }

        if (exp == 31)
        {
            if (mant == 0)
            {
                return sign == 0 ? float.PositiveInfinity : float.NegativeInfinity;
            }
            var f32Bits = ((uint)sign << 31) | (0xFFu << 23) | ((uint)mant << 13);
            return BitConverter.Int32BitsToSingle(unchecked((int)f32Bits));
        }

        var newExp = (uint)(exp - 15 + 127);
        var f32Bits2 = ((uint)sign << 31) | (newExp << 23) | ((uint)mant << 13);
        return BitConverter.Int32BitsToSingle(unchecked((int)f32Bits2));
    }
}