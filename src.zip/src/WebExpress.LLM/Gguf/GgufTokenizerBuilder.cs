using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using WebExpress.LLM.Tokenization;

namespace WebExpress.LLM.Gguf;

/// <summary>
/// Builds an <see cref="ITokenizer"/> from <c>tokenizer.ggml.*</c> metadata
/// embedded in a GGUF file. llama.cpp stores the SentencePiece vocabulary,
/// merge rules, scores, and special-token mappings inside the GGUF header
/// itself, so a model shipped as a single <c>.gguf</c> does not need a
/// separate <c>tokenizer.json</c> on disk. This builder reads the arrays
/// (vocab pieces, merge rules, scores, special-token IDs) and constructs
/// a <see cref="GemmaTokenizer"/>, since the Gemma-4 family uses the
/// SentencePiece BPE algorithm with the same <c>decode_with_offsets</c>
/// conventions that the existing tokenizer already implements.
/// </summary>
public static class GgufTokenizerBuilder
{
    /// <summary>
    /// Returns a tokenizer built from the GGUF metadata in <paramref name="gguf"/>.
    /// Throws <see cref="InvalidDataException"/> when the GGUF metadata does
    /// not contain the required <c>tokenizer.ggml.tokens</c> array.
    /// </summary>
    public static ITokenizer Build(GgufLoader gguf)
    {
        ArgumentNullException.ThrowIfNull(gguf);
        var md = gguf.Header.Metadata;

        if (!md.TryGetValue("tokenizer.ggml.tokens", out var tokensObj) ||
            tokensObj is not object[] tokensArr || tokensArr.Length == 0)
        {
            throw new InvalidDataException(
                "GGUF metadata is missing tokenizer.ggml.tokens (vocab pieces). " +
                "Cannot construct a tokenizer from this file.");
        }

        // Build vocab as Dictionary<string, int> (the dense lookup the
        // existing SentencePieceTokenizer expects). Special-token pieces
        // (control tokens: <pad>, <bos>, <eos>, <unk>, <mask>, etc.) live at
        // the very start of the GGUF vocabulary, exactly as in
        // llama.cpp-derived SentencePiece model files.
        var vocabulary = new Dictionary<string, int>(tokensArr.Length);
        for (var i = 0; i < tokensArr.Length; i++)
        {
            var piece = tokensArr[i] as string;
            if (piece == null)
            {
                throw new InvalidDataException(
                    $"tokenizer.ggml.tokens[{i}] is not a string.");
            }
            vocabulary[piece] = i;
        }

        // Merge rules: GGUF stores each merge as a string "left right".
        // GemmaTokenizer.FromVocabularyAndMerges expects the same on-disk
        // form (so we do not need to project to (left, right) tuples here).
        List<string> merges = new();
        if (md.TryGetValue("tokenizer.ggml.merges", out var mergesObj) &&
            mergesObj is object[] mergesArr)
        {
            foreach (var m in mergesArr)
            {
                if (m is string s) merges.Add(s);
            }
        }

        // Build a TokenizerConfiguration from the per-token metadata so
        // BOS / EOS / Unknown tokens match the GGUF-declared IDs.
        TokenizerConfiguration tokenizerConfig = BuildTokenizerConfig(md);

        var gemma = GemmaTokenizer.FromVocabularyAndMerges(vocabulary, merges, tokenizerConfig);
        return gemma;
    }

    private static TokenizerConfiguration BuildTokenizerConfig(IReadOnlyDictionary<string, object> md)
    {
        // The GGUF tokenizer metadata names the *IDs* of the special tokens
        // (e.g. tokenizer.ggml.bos_token_id = 2). The GemmaTokenizer
        // configuration wants their *strings* (it looks them up in the
        // vocabulary to find the IDs). For Gemma-style vocabularies the
        // standard piece strings are: <bos>, <eos>, <unk>, <pad>, <mask>.
        // We map them via the IDs in the metadata so that all five match.
        var cfg = new TokenizerConfiguration
        {
            BosToken = LookupTokenString(md, "tokenizer.ggml.bos_token_id", "<bos>"),
            EosToken = LookupTokenString(md, "tokenizer.ggml.eos_token_id", "<eos>"),
            UnkToken = LookupTokenString(md, "tokenizer.ggml.unknown_token_id", "<unk>"),
            AddBosToken = ReadBool(md, "tokenizer.ggml.add_bos_token", true),
            AddEosToken = ReadBool(md, "tokenizer.ggml.add_eos_token", false),
        };
        return cfg;

        static string LookupTokenString(
            IReadOnlyDictionary<string, object> md, string key, string fallback)
        {
            if (!md.TryGetValue(key, out var v) || v == null) return fallback;
            var id = v switch
            {
                uint u => (int)u,
                ulong ul => (int)ul,
                int i => i,
                long l => (int)l,
                _ => -1,
            };
            // The vocabulary itself is the source of truth for piece names;
            // we cannot look up id->string without it, so we just keep
            // the conventional fallback string ("<bos>" etc.). The
            // GemmaTokenizer code maps these to IDs by scanning vocab.
            _ = id;
            return fallback;
        }

        static bool ReadBool(IReadOnlyDictionary<string, object> md, string key, bool fallback)
        {
            if (!md.TryGetValue(key, out var v)) return fallback;
            return v switch { bool b => b, _ => fallback };
        }
    }
}
