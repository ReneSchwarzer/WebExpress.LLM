using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using WebExpress.LLM.Tensor;

namespace WebExpress.LLM.Gguf;

/// <summary>
/// Reads GGUF model files (the on-disk format used by llama.cpp) and exposes
/// their tensor data as <see cref="Tensor.Tensor"/> instances. Quantized
/// tensors are dequantized on the first access and then cached for the
/// lifetime of the loader.
///
/// GGUF v3 (the current spec) is supported; older v2/v1 files are rejected
/// up front. Memory-maps the file so only the touched tensor blocks are
/// pulled into the working set.
/// </summary>
public sealed class GgufLoader : IDisposable
{
    private readonly MemoryMappedFile _mmf;
    private readonly MemoryMappedViewStream _view;
    private readonly long _length;
    private readonly GgufHeader _header;
    private readonly Dictionary<string, GgufTensorInfo> _tensorIndex;
    private readonly Dictionary<string, Tensor.Tensor> _cache = new();
    private readonly object _cacheLock = new();
    private bool _disposed;

    /// <summary>Parsed GGUF header (metadata + tensor inventory).</summary>
    public GgufHeader Header => _header;

    /// <summary>Names of all tensors in the file in declaration order.</summary>
    public IReadOnlyCollection<string> TensorNames { get; }

    private GgufLoader(MemoryMappedFile mmf, MemoryMappedViewStream view, long length, GgufHeader header)
    {
        _mmf = mmf;
        _view = view;
        _length = length;
        _header = header;

        var names = new List<string>(header.TensorInfos.Count);
        _tensorIndex = new Dictionary<string, GgufTensorInfo>(header.TensorInfos.Count);
        foreach (var t in header.TensorInfos)
        {
            _tensorIndex[t.Name] = t;
            names.Add(t.Name);
        }
        TensorNames = names;
    }

    /// <summary>
    /// Open a GGUF file and parse its header. The file remains memory-mapped
    /// for the loader's lifetime; tensor data is read on demand.
    /// </summary>
    /// <param name="filePath">Path to a .gguf file on disk.</param>
    public static GgufLoader Open(string filePath)
    {
        var fi = new FileInfo(filePath);
        if (!fi.Exists)
        {
            throw new FileNotFoundException($"GGUF file not found: {filePath}", filePath);
        }

        var mmf = MemoryMappedFile.CreateFromFile(
            fi.FullName, FileMode.Open, mapName: null, capacity: fi.Length, MemoryMappedFileAccess.Read);
        var view = mmf.CreateViewStream(0, fi.Length, MemoryMappedFileAccess.Read);
        GgufHeader header;
        try
        {
            header = GgufHeaderParser.Parse(view, fi.Length);
        }
        catch
        {
            view.Dispose();
            mmf.Dispose();
            throw;
        }
        return new GgufLoader(mmf, view, fi.Length, header);
    }

    /// <summary>True when the inventory contains a tensor with this exact name.</summary>
    public bool ContainsTensor(string name) => _tensorIndex.ContainsKey(name);

    /// <summary>Look up tensor metadata by name.</summary>
    public GgufTensorInfo GetMetadata(string name)
    {
        if (!_tensorIndex.TryGetValue(name, out var info))
        {
            throw new KeyNotFoundException($"GGUF tensor '{name}' not in inventory.");
        }
        return info;
    }

    /// <summary>
    /// Load a tensor by name and decode it into a <see cref="Tensor.Tensor"/>.
    /// Result is cached — repeated calls return the same instance.
    /// </summary>
    public Tensor.Tensor LoadTensor(string name)
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(GgufLoader));
        }

        lock (_cacheLock)
        {
            if (_cache.TryGetValue(name, out var cached))
            {
                return cached;
            }

            if (!_tensorIndex.TryGetValue(name, out var info))
            {
                throw new KeyNotFoundException($"GGUF tensor '{name}' not in inventory.");
            }

            var elementCount = (long)info.ElementCount;
            var output = new float[elementCount];
            DecodeTensor(info, output);

            // GGUF tensor shape is declared as [..., 1] for 1-D, [..., rows, cols] for 2-D,
            // and so on. Convert ulong dims to int32 for the WebExpress tensor.
            var shape = new int[info.Shape.Count];
            for (var i = 0; i < info.Shape.Count; i++)
            {
                shape[i] = checked((int)info.Shape[i]);
            }

            var tensor = Tensor.Tensor.Owning(shape, output);
            _cache[name] = tensor;
            return tensor;
        }
    }

    /// <summary>Returns null when the tensor is absent; otherwise <see cref="LoadTensor"/>.</summary>
    public Tensor.Tensor? TryLoadTensor(string name)
    {
        return ContainsTensor(name) ? LoadTensor(name) : null;
    }

    private void DecodeTensor(GgufTensorInfo info, float[] output)
    {
        var dataStart = _header.TensorDataStart + (long)info.Offset;
        if (dataStart < 0 || dataStart >= _length)
        {
            throw new InvalidDataException(
                $"Tensor '{info.Name}' data offset {dataStart} is outside the file (length {_length}).");
        }

        // Map the slice we need. For F32/F16/BF16 this is exactly the byte
        // count; for quantized types the entire block range is consumed.
        var payloadSize = GgufDequantizer.ByteSize(info.Type, info.ElementCount);
        if (payloadSize == 0)
        {
            // Quantized types report 0 from ByteSize — read to the end of the
            // file. In practice we should always know the exact size from the
            // dequantizer, so throw if the type is unsupported.
            throw new NotSupportedException(
                $"Tensor '{info.Name}' uses type {info.Type}; size estimation requires the dequantizer.");
        }

        var bytes = ReadSlice(dataStart, (long)payloadSize);
        GgufDequantizer.Dequantize(info.Type, bytes, output, info.ElementCount);
    }

    private ReadOnlySpan<byte> ReadSlice(long offset, long length)
    {
        if (offset + length > _length)
        {
            throw new InvalidDataException(
                $"Slice at offset {offset} with length {length} exceeds file size {_length}.");
        }

        var buffer = new byte[length];
        _view.Position = offset;
        var read = 0;
        while (read < length)
        {
            var n = _view.Read(buffer, read, (int)(length - read));
            if (n == 0) break;
            read += n;
        }
        return buffer;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _view.Dispose();
        _mmf.Dispose();
    }
}