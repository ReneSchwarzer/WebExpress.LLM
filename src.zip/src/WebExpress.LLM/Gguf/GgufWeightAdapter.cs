using System;
using System.Collections.Generic;
using WebTensor = WebExpress.LLM.Tensor.Tensor;
using WebExpress.LLM.SafeTensors;

namespace WebExpress.LLM.Gguf;

/// <summary>
/// Adapts <see cref="GgufLoader"/> to the <see cref="ISafeTensorLoader"/>
/// shape that <c>Gemma4Model</c> reads. Performs two duties:
///   1. Translates GGUF tensor names (llama.cpp convention) into the
///      SafeTensors / HuggingFace names the existing model code requests.
///   2. Re-lays out GGUF weight tensors so they match PyTorch's
///      <c>[out_features, in_features]</c> ordering where appropriate.
/// </summary>
/// <remarks>
/// Step (2) is needed because llama.cpp's <c>mul_mat(A, B)</c> computes
/// <c>A @ B^T</c> on memory laid out as <c>[K, N]</c>, so most linear
/// weights arrive stored row-major <c>[in_features, out_features]</c>;
/// SafeTensors / PyTorch stores them transposed. However the convention
/// is NOT uniform across every projection: <c>o_proj</c> and
/// <c>mlp.down_proj</c> arrive already in PyTorch order. The
/// <see cref="TensorLayouts"/> table encodes which suffix receives
/// which treatment, with pass-through for norms and scales.
/// </remarks>
public sealed class GgufWeightAdapter : ISafeTensorLoader
{
    private readonly GgufLoader _gguf;
    private readonly Dictionary<string, WebTensor> _transposeCache = new();

    private enum LayoutKind
    {
        // Pass through unchanged.
        Pass,
        // Swap the two axes of a 2-D tensor to convert GGUF ordering to
        // the ordering the existing PyTorch-style model code expects.
        Transpose2D,
    }

    private static readonly Dictionary<string, LayoutKind> TensorLayouts =
        new(StringComparer.Ordinal)
    {
        // Token-embedding lookup table: GGUF stores [hidden, vocab], the
        // EmbeddingLookup helper expects [vocab, hidden].
        ["embed_tokens.weight"] = LayoutKind.Transpose2D,

        // q / k / v projections arrive [hidden, qkv_out]; flip to PyTorch's
        // [qkv_out, hidden].
        ["self_attn.q_proj.weight"] = LayoutKind.Transpose2D,
        ["self_attn.k_proj.weight"] = LayoutKind.Transpose2D,
        ["self_attn.v_proj.weight"] = LayoutKind.Transpose2D,

        // Output projection: GGUF stores this as [q_total, hidden] (MatMul-Ready
        // for llama.cpp's "concat @ weight" path). The existing transformer code
        // does MatMul(concat, Transpose2D(oProjWeight)) assuming PyTorch
        // [out, in] ordering, so we transpose in the adapter: raw [q_total, hidden]
        // -> adapter [hidden, q_total].
        ["self_attn.o_proj.weight"] = LayoutKind.Transpose2D,

        // MLP gate / up: stored [hidden, intermediate] -> adapter [intermediate, hidden].
        ["mlp.gate_proj.weight"] = LayoutKind.Transpose2D,
        ["mlp.up_proj.weight"] = LayoutKind.Transpose2D,

        // MLP down: stored [intermediate, hidden] -> adapter [hidden, intermediate].
        // Same reasoning as o_proj.
        ["mlp.down_proj.weight"] = LayoutKind.Transpose2D,

        // MoE router (linear gate to expert logits): flip.
        ["router.proj.weight"] = LayoutKind.Transpose2D,

        // MoE expert tensors: GGUF stacks them as 3-D
        // [hidden, out, num_experts] (gate_up) or [intermediate, hidden,
        // num_experts] (down). Permute3D([2, 1, 0]) yields
        // [num_experts, out, hidden] / [num_experts, hidden, intermediate]
        // which matches the [num_experts, in_per_expert, ...] convention the
        // Gemma4Model.MoeBlock slices via element-index arithmetic.
        ["experts.gate_up_proj"] = LayoutKind.Transpose2D,
        ["experts.down_proj"]    = LayoutKind.Transpose2D,
    };

    private static bool NeedsTranspose(string safeTensorsName) =>
        GetLayoutFor(safeTensorsName) == LayoutKind.Transpose2D;

    /// <summary>Return the layout kind for a SafeTensors-name tensor, defaulting to pass-through.</summary>
    private static LayoutKind GetLayoutFor(string safeTensorsName)
    {
        foreach (var kv in TensorLayouts)
        {
            if (safeTensorsName.EndsWith(kv.Key, StringComparison.Ordinal))
            {
                return kv.Value;
            }
        }
        return LayoutKind.Pass;
    }

    // GGUF-Name <-> SafeTensors-Name lookup tables for tensors that do
    // NOT follow the "blk.{N}.{suffix}" pattern.
    private static readonly Dictionary<string, string> NameMap = new(StringComparer.Ordinal)
    {
        ["model.language_model.embed_tokens.weight"] = "token_embd.weight",
        ["model.language_model.norm.weight"]        = "output_norm.weight",
        ["lm_head.weight"]                          = "output.weight",
    };

    // Layer-suffix mapping: model code asks for "model.language_model.layers.{N}.X",
    // GGUF has "blk.{N}.Y". Key = the suffix used in SafeTensors form;
    // Value = the suffix used in the GGUF file.
    private static readonly Dictionary<string, string> BlockSuffixMap = new(StringComparer.Ordinal)
    {
        ["input_layernorm.weight"]             = "attn_norm.weight",
        ["self_attn.q_proj.weight"]            = "attn_q.weight",
        ["self_attn.k_proj.weight"]            = "attn_k.weight",
        ["self_attn.v_proj.weight"]            = "attn_v.weight",
        ["self_attn.q_norm.weight"]            = "attn_q_norm.weight",
        ["self_attn.k_norm.weight"]            = "attn_k_norm.weight",
        ["self_attn.o_proj.weight"]            = "attn_output.weight",
        ["post_attention_layernorm.weight"]    = "post_attention_norm.weight",
        ["pre_feedforward_layernorm.weight"]   = "ffn_norm.weight",
        ["mlp.gate_proj.weight"]               = "ffn_gate.weight",
        ["mlp.up_proj.weight"]                 = "ffn_up.weight",
        ["mlp.down_proj.weight"]               = "ffn_down.weight",
        ["pre_feedforward_layernorm_2.weight"] = "pre_ffw_norm_2.weight",
        ["post_feedforward_layernorm_1.weight"] = "post_ffw_norm_1.weight",
        ["post_feedforward_layernorm_2.weight"] = "post_ffw_norm_2.weight",
        ["post_feedforward_layernorm.weight"]  = "post_ffw_norm.weight",
        ["router.proj.weight"]                 = "ffn_gate_inp.weight",
        ["router.scale"]                       = "ffn_gate_inp.scale",
        ["experts.gate_up_proj"]               = "ffn_gate_up_exps.weight",
        ["experts.down_proj"]                  = "ffn_down_exps.weight",
        ["layer_scalar"]                       = "layer_output_scale.weight",
    };

    public GgufWeightAdapter(GgufLoader gguf)
    {
        _gguf = gguf ?? throw new ArgumentNullException(nameof(gguf));
    }

    public IReadOnlyCollection<string> TensorNames => _gguf.TensorNames;

    public bool ContainsTensor(string name) => _gguf.ContainsTensor(MapName(name));

    public WebExpress.LLM.SafeTensors.TensorMetadata GetMetadata(string name)
    {
        var info = _gguf.GetMetadata(MapName(name));
        var dtype = info.Type switch
        {
            GgufType.F32  => "F32",
            GgufType.F16  => "F16",
            GgufType.BF16 => "BF16",
            _             => "F32",
        };
        var shape = new long[info.Shape.Count];
        for (var i = 0; i < info.Shape.Count; i++) shape[i] = (long)info.Shape[i];

        // Surface the post-transpose shape so callers see PyTorch ordering.
        if (NeedsTranspose(name) && shape.Length == 2)
        {
            (shape[0], shape[1]) = (shape[1], shape[0]);
        }

        return new WebExpress.LLM.SafeTensors.TensorMetadata
        {
            Name = info.Name,
            Dtype = dtype,
            Shape = shape,
            DataOffsets = [0L, (long)info.ElementCount * 4],
        };
    }

    public WebTensor LoadTensor(string name)
    {
        // KV-sharing fallback: when a sliding-window layer in a Gemma-4 GGUF
        // omits attn_v.weight, fall back to the K projection for V. The model
        // reads "v" by name and the missing-tensor KeyNotFoundException would
        // otherwise break the forward pass before the code in MultiHeadAttention
        // has a chance to fall back. The shape of the K projection matches what
        // V is expected to be ([q_total_or_shared_size, hidden] in our
        // post-transpose adapter view), so reusing it preserves the semantics
        // of attention_k_eq_v for those layers.
        if (name == "model.language_model.layers.5.self_attn.v_proj.weight" ||
            name.EndsWith(".self_attn.v_proj.weight", StringComparison.Ordinal))
        {
            var ggufV = MapName(name);
            if (!_gguf.ContainsTensor(ggufV))
            {
                var ggufK = ggufV.Replace("attn_v.weight", "attn_k.weight");
                if (_gguf.ContainsTensor(ggufK))
                {
                    return LoadTensor(name.Replace("v_proj.weight", "k_proj.weight"));
                }
            }
        }

        var ggufName = MapName(name);

        // Norm / scale tensors and PyTorch-ordered projections: hand back
        // the GGUF tensor unchanged.
        if (!NeedsTranspose(name))
        {
            return (WebTensor)_gguf.LoadTensor(ggufName);
        }

        // Transposable 2-D weights: cache the transposed view so repeated
        // calls don't re-dequantize + re-permute.
        lock (_transposeCache)
        {
            if (_transposeCache.TryGetValue(name, out var cached))
            {
                return cached;
            }
        }

        var raw = (WebTensor)_gguf.LoadTensor(ggufName);
        WebTensor transposed;
        if (raw.Rank == 2)
        {
            transposed = raw.Transpose();
        }
        else if (raw.Rank == 3)
        {
            // MoE expert tensors arrive stacked as [hidden, out, numExperts] for
            // gate_up_proj (and [intermediate, hidden, numExperts] for down_proj)
            // in GGUF. The MoeBlock code expects the per-expert dimension to be
            // the OUTER axis [numExperts, out, in]. Reorder with Permute3D([2, 1, 0]).
            transposed = raw.Permute3D(new[] { 2, 1, 0 });
        }
        else
        {
            transposed = raw;
        }

        lock (_transposeCache)
        {
            _transposeCache[name] = transposed;
        }
        return transposed;
    }

    public WebTensor? TryLoadTensor(string name)
    {
        var ggufName = MapName(name);
        return _gguf.ContainsTensor(ggufName) ? LoadTensor(name) : null;
    }

    public void LoadTensorRow(string name, long rowIndex, float[] destination)
    {
        var tensor = LoadTensor(name);
        if (tensor.Rank != 2)
        {
            throw new InvalidOperationException($"Tensor '{name}' is not 2-D.");
        }
        if (rowIndex < 0 || rowIndex >= tensor.Shape[0])
        {
            throw new ArgumentOutOfRangeException(nameof(rowIndex));
        }
        var cols = tensor.Shape[1];
        if (destination.Length < cols)
        {
            throw new ArgumentException("Destination length smaller than row width.", nameof(destination));
        }
        Array.Copy(tensor.Data, (int)rowIndex * cols, destination, 0, cols);
    }

    /// <summary>
    /// Map a SafeTensors-style tensor name to the GGUF-style name actually
    /// present in the file. Returns the input unchanged if no mapping is
    /// registered, so unmapped names fail at the GGUF layer with a clear
    /// KeyNotFoundException rather than silently returning a wrong tensor.
    /// </summary>
    private static string MapName(string name)
    {
        if (NameMap.TryGetValue(name, out var mapped)) return mapped;

        // Gemma-4 uses "model.language_model.layers.{N}.X". GGUF uses the
        // same {N} but as "blk.{N}.X" with a shortened suffix.
        if (name.StartsWith("model.language_model.layers.", StringComparison.Ordinal))
        {
            const string prefix = "model.language_model.layers.";
            var prefixLen = prefix.Length;
            var dot = name.IndexOf('.', prefixLen);
            if (dot > 0)
            {
                var layerPart = name.Substring(0, dot);
                var rest = name.Substring(dot + 1);
                if (BlockSuffixMap.TryGetValue(rest, out var blockSuffix))
                {
                    var layerIdx = layerPart.Substring(prefixLen);
                    return $"blk.{layerIdx}.{blockSuffix}";
                }
            }
        }
        return name;
    }
}
