using System;
using System.Collections.Generic;
using System.Linq;
using WebExpress.LLM.Model;
using WebExpress.LLM.SafeTensors;

namespace WebExpress.LLM.Gguf;

/// <summary>
/// Builds a <see cref="ModelConfiguration"/> for Gemma-4 from the metadata
/// of an open GGUF file. Maps llama.cpp's <c>gemma4.*</c> keys onto the
/// SafeTensors/HuggingFace config schema that <c>Gemma4Model</c> reads.
/// </summary>
public static class GgufModelConfigurationBuilder
{
    public static ModelConfiguration Build(GgufLoader gguf)
    {
        ArgumentNullException.ThrowIfNull(gguf);
        var md = gguf.Header.Metadata;

        var vocabSize = (int)ReadUInt(md, "gemma4.vocab_size", 0);
        if (vocabSize == 0)
        {
            // Fall back: token-embedding tensor. GGUF stores this as
            // [hidden, vocab] = [2816, 262144] for Gemma-4, so the vocab size
            // is the LAST dimension, not the first. (rows of the embedding
            // matrix equal hidden_size; columns equal vocab_size)
            var tokenEmb = gguf.Header.TensorInfos.FirstOrDefault(t => t.Name == "token_embd.weight");
            if (tokenEmb != null && tokenEmb.Shape.Count >= 2)
            {
                vocabSize = checked((int)tokenEmb.Shape[tokenEmb.Shape.Count - 1]);
            }
        }

        return new ModelConfiguration
        {
            ModelName = md.TryGetValue("general.name", out var n) ? n as string ?? "" : "",
            ModelType = "gemma4",
            Dtype = "F32",
            VocabularySize = vocabSize,
            ContextLength = (int)ReadUInt(md, "gemma4.context_length", 0),
            HiddenSize = (int)ReadUInt(md, "gemma4.embedding_length", 0),
            IntermediateSize = (int)ReadUInt(md, "gemma4.feed_forward_length", 0),
            NumberOfLayers = (int)ReadUInt(md, "gemma4.block_count", 0),
            NumberOfAttentionHeads = (int)ReadUInt(md, "gemma4.attention.head_count", 0),
            RmsNormEpsilon = (float)ReadDouble(md, "gemma4.attention.layer_norm_rms_epsilon", 1e-6),
            TieWordEmbeddings = !gguf.Header.TensorInfos.Any(t => t.Name == "output.weight"),
            NumberOfKeyValueHeads = FirstKvHeadCount(md),
            HeadDimension = ResolveHeadDimension(gguf),
            TextConfig = new TextConfig
            {
                HiddenSizePerLayerInput    = (int)ReadUInt(md, "gemma4.embedding_length_per_layer_input", 0),
                VocabSizePerLayerInput      = (int)ReadUInt(md, "gemma4.vocab_size_per_layer_input", 0),
                FinalLogitSoftcapping       = (float)ReadDouble(md, "gemma4.final_logit_softcapping", 0.0),
                NumberOfKvSharedLayers      = (int)ReadUInt(md, "gemma4.attention.shared_kv_layers", 0),
                AttentionKeyEqualsValue     = ReadBool(md, "gemma4.attention.key_equals_value", false),
                NumberOfGlobalKeyValueHeads = ResolveGlobalKvHeads(md),
                GlobalHeadDimension         = ResolveGlobalHeadDim(md),
                SlidingWindow                = (int)ReadUInt(md, "gemma4.attention.sliding_window", 0),
                AttentionLogitsSoftcapping   = (float)ReadDouble(md, "gemma4.attention.logit_softcapping", 0.0),
                EnableMoeBlock = md.TryGetValue("gemma4.expert_count", out var ec) && ConvertToLong(ec) > 1,
                UseSecondMlpBlock = false,
                TopKExperts = (int)ReadUInt(md, "gemma4.expert_used_count", 0),
                LayerTypes = BuildLayerTypes(md),
                RopeParameters = BuildRopeParameters(md),
            }
        };
    }

    private static ulong ReadUInt(IReadOnlyDictionary<string, object> md, string key, ulong fallback)
    {
        if (!md.TryGetValue(key, out var v) || v == null) return fallback;
        return ConvertToUlong(v);
    }

    private static double ReadDouble(IReadOnlyDictionary<string, object> md, string key, double fallback)
    {
        if (!md.TryGetValue(key, out var v) || v == null) return fallback;
        return v switch
        {
            double d => d,
            float f  => f,
            uint u   => u,
            ulong ul => ul,
            int i    => i,
            long l   => l,
            _ => fallback,
        };
    }

    private static bool ReadBool(IReadOnlyDictionary<string, object> md, string key, bool fallback)
    {
        if (!md.TryGetValue(key, out var v) || v == null) return fallback;
        return v switch
        {
            bool b => b,
            _ => fallback,
        };
    }

    private static ulong ConvertToUlong(object v) => v switch
    {
        uint u => u,
        ulong ul => ul,
        int i => (ulong)i,
        long l => (ulong)l,
        double d => (ulong)d,
        float f => (ulong)f,
        _ => 0,
    };

    private static long ConvertToLong(object v) => v switch
    {
        int i => i,
        long l => l,
        uint u => u,
        ulong ul => (long)ul,
        double d => (long)d,
        float f => (long)f,
        _ => 0,
    };

    private static int FirstKvHeadCount(IReadOnlyDictionary<string, object> md)
    {
        if (!md.TryGetValue("gemma4.attention.head_count_kv", out var v) || v is not object[] arr || arr.Length == 0)
        {
            return 0;
        }
        return (int)ConvertToLong(arr[0]);
    }

    private static int ResolveGlobalKvHeads(IReadOnlyDictionary<string, object> md)
    {
        var explicitVal = (int)ReadUInt(md, "gemma4.attention.head_count_kv_global", 0);
        if (explicitVal > 0) return explicitVal;
        if (md.TryGetValue("gemma4.attention.head_count_kv", out var v) && v is object[] arr && arr.Length > 0)
        {
            return (int)ConvertToLong(arr[0]);
        }
        return 0;
    }

    private static int ResolveHeadDimension(GgufLoader gguf)
    {
        // gemma4.attention.key_length reports the effective key length used
        // for RoPE / shared-KV, but the per-head length of the q_proj /
        // k_proj linear weights often differs in practice (Gemma-4 uses
        // head_dim=256 even when the metadata says 512). The only reliable
        // source is the actual tensor shape: head_dim = q_proj_shape[0] /
        // num_query_heads (transposed view).
        var numQueryHeads = (int)ReadUInt(gguf.Header.Metadata, "gemma4.attention.head_count", 0);
        var qProj = gguf.Header.TensorInfos.FirstOrDefault(t => t.Name == "blk.0.attn_q.weight");
        if (qProj != null && qProj.Shape.Count >= 2 && numQueryHeads > 0)
        {
            // After transpose the leading dim is "q_out". q_head_dim is
            // computed against the *largest* leading dim we can find across
            // full layers (some layers may shrink for sliding-window).
            int qOut = checked((int)qProj.Shape[1]); // raw [hidden, q_out]
            if (qOut % numQueryHeads == 0)
            {
                return qOut / numQueryHeads;
            }
        }
        // Fall back to the metadata value (may be inaccurate for Gemma-4
        // but is the best we have when the tensor lookup fails).
        return (int)ReadUInt(gguf.Header.Metadata, "gemma4.attention.key_length", 0);
    }

    private static int ResolveGlobalHeadDim(IReadOnlyDictionary<string, object> md)
    {
        return (int)ReadUInt(md, "gemma4.attention.key_length_global", 0);
    }


    private static IReadOnlyList<string> BuildLayerTypes(IReadOnlyDictionary<string, object> md)
    {
        if (!md.TryGetValue("gemma4.attention.sliding_window_pattern", out var v) || v is not object[] arr)
        {
            return ["sliding"];
        }
        var result = new List<string>(arr.Length);
        foreach (var item in arr)
        {
            var isFull = item switch { bool b => b, _ => false };
            result.Add(isFull ? "full_attention" : "sliding");
        }
        return result;
    }

    private static TextRopeParameters BuildRopeParameters(IReadOnlyDictionary<string, object> md)
    {
        var partialFactor = (float)ReadDouble(md, "gemma4.rope.partial_rotary_factor", 1.0);
        var full = new RopeEntry
        {
            RopeTheta = (float)ReadDouble(md, "gemma4.rope.freq_base", 10000.0f),
            RopeType = "default",
            PartialRotaryFactor = partialFactor,
        };
        var sliding = new RopeEntry
        {
            RopeTheta = (float)ReadDouble(md, "gemma4.rope.freq_base_swa", 10000.0f),
            RopeType = "default",
            PartialRotaryFactor = partialFactor,
        };
        return new TextRopeParameters
        {
            FullAttention = full,
            SlidingAttention = sliding,
        };
    }
}