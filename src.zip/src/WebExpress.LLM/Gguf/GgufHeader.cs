using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace WebExpress.LLM.Gguf;

/// <summary>
/// Parsed GGUF file header (magic, version, tensor count, metadata KV count).
/// Holds the metadata key-value pairs and the tensor inventory in declaration
/// order. The actual tensor data follows the inventory at a file-relative offset.
/// </summary>
public sealed class GgufHeader
{
    /// <summary>GGUF magic bytes, little-endian ("GGUF" = 0x46554747).</summary>
    public const uint Magic = 0x46554747;

    /// <summary>Highest GGUF version this loader understands.</summary>
    public const uint SupportedVersion = 3;

    /// <summary>Default alignment when <c>general.alignment</c> is not set in metadata.</summary>
    public const uint DefaultAlignment = 32;

    public uint Version { get; }
    public ulong TensorCount { get; }
    public ulong MetadataKvCount { get; }
    public IReadOnlyDictionary<string, object> Metadata { get; }
    public IReadOnlyList<GgufTensorInfo> TensorInfos { get; }

    /// <summary>File offset (in bytes) at which tensor data begins, after alignment padding.</summary>
    public long TensorDataStart { get; }

    public GgufHeader(
        uint version,
        ulong tensorCount,
        ulong metadataKvCount,
        IReadOnlyDictionary<string, object> metadata,
        IReadOnlyList<GgufTensorInfo> tensorInfos,
        long tensorDataStart)
    {
        Version = version;
        TensorCount = tensorCount;
        MetadataKvCount = metadataKvCount;
        Metadata = metadata;
        TensorInfos = tensorInfos;
        TensorDataStart = tensorDataStart;
    }

    /// <summary>
    /// Returns the global alignment in bytes (default 32 if missing).
    /// </summary>
    public uint Alignment()
    {
        if (Metadata.TryGetValue("general.alignment", out var v))
        {
            return v switch
            {
                uint u => u,
                ulong ul => (uint)ul,
                int i => (uint)i,
                long l => (uint)l,
                _ => DefaultAlignment,
            };
        }
        return DefaultAlignment;
    }

    /// <summary>Look up a tensor by exact name; null if not present.</summary>
    public GgufTensorInfo? FindTensor(string name)
    {
        foreach (var t in TensorInfos)
        {
            if (t.Name == name) return t;
        }
        return null;
    }
}

/// <summary>
/// One tensor entry in the GGUF tensor inventory. The data lives at
/// <c>(file offset of TensorDataStart) + Offset</c>.
/// </summary>
public sealed class GgufTensorInfo
{
    public string Name { get; }
    public IReadOnlyList<ulong> Shape { get; }
    public GgufType Type { get; }
    public ulong Offset { get; }

    public GgufTensorInfo(string name, IReadOnlyList<ulong> shape, GgufType type, ulong offset)
    {
        Name = name;
        Shape = shape;
        Type = type;
        Offset = offset;
    }

    /// <summary>Total number of float32 elements this tensor decodes to.</summary>
    public ulong ElementCount
    {
        get
        {
            ulong n = 1;
            foreach (var d in Shape) n *= d;
            return n;
        }
    }

    /// <summary>Human-readable shape string, e.g. "[2048, 2048]".</summary>
    public string ShapeString => "[" + string.Join(", ", Shape) + "]";
}

/// <summary>
/// Parses a GGUF file's header (magic + version + metadata KV list + tensor inventory)
/// from a memory-mapped view. The view must remain alive while the resulting
/// <see cref="GgufHeader"/> is used because the strings point into the buffer.
/// </summary>
internal static class GgufHeaderParser
{
    /// <summary>
    /// Parse the GGUF header from the head of <paramref name="view"/>.
    /// On success returns the parsed header plus the byte offset just past the
    /// tensor inventory (where alignment padding and tensor data start).
    /// </summary>
    public static GgufHeader Parse(Stream stream, long length)
    {
        if (length < 8)
        {
            throw new InvalidDataException("GGUF header is shorter than 8 bytes.");
        }

        var reader = new BinaryReader(stream, Encoding.UTF8, leaveOpen: true);
        reader.BaseStream.Position = 0;

        var magic = reader.ReadUInt32();
if (magic != GgufHeader.Magic)
        {
            throw new InvalidDataException(
                $"GGUF magic mismatch: expected 0x{GgufHeader.Magic:X8}, got 0x{magic:X8}.");
        }

        var version = reader.ReadUInt32();
if (version == 0 || version > GgufHeader.SupportedVersion)
        {
            throw new InvalidDataException(
                $"Unsupported GGUF version {version}; this loader supports up to v{GgufHeader.SupportedVersion}.");
        }

        var tensorCount = reader.ReadUInt64();
        var kvCount = reader.ReadUInt64();

        var metadata = new Dictionary<string, object>((int)kvCount);
        for (ulong i = 0; i < kvCount; i++)
        {
            var key = ReadString(reader);
            var vt = (GgufMetadataValueType)reader.ReadUInt32();
            var val = ReadMetadataValue(reader, vt);
            metadata[key] = val;
        }

        var tensors = new List<GgufTensorInfo>((int)tensorCount);
        for (ulong i = 0; i < tensorCount; i++)
        {
            var name = ReadString(reader);
var nDims = reader.ReadUInt32();
if (nDims > 8)
            {
                throw new InvalidDataException(
                    $"Tensor '{name}' has {nDims} dimensions, refusing to parse (sanity cap is 8).");
            }

            var dims = new ulong[nDims];
            for (var d = 0; d < nDims; d++) dims[d] = reader.ReadUInt64();
            var type = (GgufType)reader.ReadUInt32();
            var offset = reader.ReadUInt64();

            tensors.Add(new GgufTensorInfo(name, dims, type, offset));
        }

        // Tensor data begins at the next aligned offset past the header+inventory.
        var alignment = metadata.TryGetValue("general.alignment", out var av) && av is uint avU ? avU : GgufHeader.DefaultAlignment;
        if (alignment == 0 || (alignment & (alignment - 1)) != 0)
        {
            // Bad alignment value: fall back to default.
            alignment = GgufHeader.DefaultAlignment;
        }

        var endOfHeader = reader.BaseStream.Position;
        var aligned = AlignUp(endOfHeader, alignment);

        return new GgufHeader(version, tensorCount, kvCount, metadata, tensors, aligned);
    }

    private static long AlignUp(long value, uint alignment)
    {
        var rem = value % alignment;
        return rem == 0 ? value : value + (alignment - rem);
    }

    private static string ReadString(BinaryReader reader)
    {
        var len = reader.ReadUInt64();
        if (len > int.MaxValue)
        {
            throw new InvalidDataException($"GGUF string length {len} exceeds 2 GB.");
        }
        var bytes = reader.ReadBytes((int)len);
        return Encoding.UTF8.GetString(bytes);
    }

    private static object ReadMetadataValue(BinaryReader reader, GgufMetadataValueType vt)
    {
        switch (vt)
        {
            case GgufMetadataValueType.UInt8:   return reader.ReadByte();
            case GgufMetadataValueType.Int8:    return reader.ReadSByte();
            case GgufMetadataValueType.UInt16:  return reader.ReadUInt16();
            case GgufMetadataValueType.Int16:   return reader.ReadInt16();
            case GgufMetadataValueType.UInt32:  return reader.ReadUInt32();
            case GgufMetadataValueType.Int32:   return reader.ReadInt32();
            case GgufMetadataValueType.Float32: return reader.ReadSingle();
            case GgufMetadataValueType.Bool:    return reader.ReadByte() != 0;
            case GgufMetadataValueType.String:  return ReadString(reader);
            case GgufMetadataValueType.UInt64:  return reader.ReadUInt64();
            case GgufMetadataValueType.Int64:   return reader.ReadInt64();
            case GgufMetadataValueType.Float64: return reader.ReadDouble();
            case GgufMetadataValueType.Array:
            {
                var elemType = (GgufMetadataValueType)reader.ReadUInt32();
                var count = reader.ReadUInt64();
                if (count > int.MaxValue)
                {
                    throw new InvalidDataException($"GGUF array length {count} exceeds int.MaxValue.");
                }
                var arr = new object[(int)count];
                for (var i = 0; i < (int)count; i++)
                {
                    arr[i] = ReadMetadataValue(reader, elemType);
                }
                return arr;
            }
            default:
                throw new InvalidDataException($"Unknown GGUF metadata value type {vt}.");
        }
    }
}