using System;
using System.Threading.Tasks;
using WebExpress.LLM.Tensor;

namespace WebExpress.LLM.Gemma;

/// <summary>
/// Implements the multi-head attention mechanism used in Gemma-4 transformer layers,
/// supporting both full attention and sliding window attention patterns.
/// </summary>
/// <remarks>
/// Gemma-4 uses grouped-query attention (GQA) where a smaller number of key-value heads
/// are shared across multiple query heads. It alternates between sliding window attention
/// (512-token window) and full causal attention across its 35 layers.
/// </remarks>
public sealed class MultiHeadAttention
{
    /// <summary>
    /// Large negative value used to mask attention logits. Matches the Gemma
    /// reference (<c>gemma/gm/nn/gemma4/_modules.py</c>, <c>K_MASK</c>). Using a
    /// finite value rather than <see cref="float.NegativeInfinity"/> keeps the
    /// softmax well-defined even when an entire row is masked (e.g. an empty
    /// sliding window with bfloat16 later on).
    /// </summary>
    public const float MaskValue = -1e30f;

    private readonly int _numQueryHeads;
    private readonly int _numKvHeads;
    private readonly int _headDim;
    private readonly bool _isFullAttention;
    private readonly int _slidingWindowSize;
    private readonly RotaryEmbedding _rope;
    private readonly float _attentionLogitsSoftcap;

    /// <summary>
    /// Initializes a new MultiHeadAttention layer.
    /// </summary>
    /// <param name="numQueryHeads">Number of query attention heads.</param>
    /// <param name="numKvHeads">Number of key-value attention heads (for GQA).</param>
    /// <param name="headDim">Dimension of each attention head.</param>
    /// <param name="isFullAttention">Whether this layer uses full attention (true) or sliding window (false).</param>
    /// <param name="slidingWindowSize">The sliding window size for local attention.</param>
    /// <param name="rope">The rotary position embedding to apply to queries and keys.</param>
    /// <param name="attentionLogitsSoftcap">
    /// Optional soft-cap applied to pre-softmax attention scores via
    /// <c>tanh(score / cap) * cap</c>. A value of 0 (the default) disables the
    /// soft cap. Used by Gemma-2 and some Gemma-4 variants to stabilise training.
    /// </param>
    public MultiHeadAttention(
        int numQueryHeads,
        int numKvHeads,
        int headDim,
        bool isFullAttention,
        int slidingWindowSize,
        RotaryEmbedding rope,
        float attentionLogitsSoftcap = 0f)
    {
        _numQueryHeads = numQueryHeads;
        _numKvHeads = numKvHeads;
        _headDim = headDim;
        _isFullAttention = isFullAttention;
        _slidingWindowSize = slidingWindowSize;
        _rope = rope ?? throw new ArgumentNullException(nameof(rope));
        _attentionLogitsSoftcap = attentionLogitsSoftcap;
    }

    /// <summary>
    /// Computes the multi-head attention forward pass.
    /// </summary>
    /// <param name="input">Input tensor of shape [seqLen, hiddenSize].</param>
    /// <param name="qProjWeight">Query projection weight [numQueryHeads * headDim, hiddenSize].</param>
    /// <param name="kProjWeight">Key projection weight [numKvHeads * headDim, hiddenSize].
    /// May be <c>null</c> when <paramref name="kvSharingTargetLayer"/> is set.</param>
    /// <param name="vProjWeight">Value projection weight [numKvHeads * headDim, hiddenSize].
    /// May be <c>null</c> when <paramref name="kvSharingTargetLayer"/> is set.</param>
    /// <param name="oProjWeight">Output projection weight [hiddenSize, numQueryHeads * headDim].</param>
    /// <param name="kvCache">Optional KV cache for autoregressive generation.</param>
    /// <param name="layerIndex">The layer index (used for KV cache keying).</param>
    /// <param name="qNormWeight">Optional per-head query RMSNorm weight of shape [qHeadDim], applied before RoPE.</param>
    /// <param name="kNormWeight">Optional per-head key RMSNorm weight of shape [kHeadDim], applied before RoPE.
    /// Ignored when <paramref name="kvSharingTargetLayer"/> is set.</param>
    /// <param name="rmsNormEpsilon">Epsilon used for the optional q/k RMSNorm operations.</param>
    /// <param name="kvSharingTargetLayer">When set, the layer reuses K/V from the
    /// specified target layer's KV cache instead of computing its own K/V projections.
    /// Mirrors vLLM's <c>num_kv_shared_layers</c> mechanism (gemma4.py:520-533).</param>
    /// <returns>The attention output of shape [seqLen, hiddenSize].</returns>
    /// <remarks>
    /// The Gemma-4 reference (<c>gemma/gm/nn/gemma4/_modules.Attention</c>) applies a
    /// scale-less <c>value_norm</c> to V after the projection, before the KV-cache
    /// update. It also computes the attention logits as a plain
    /// <c>einsum('BTNH,BSNH-&gt;BTNS', q, k)</c> with no <c>1/sqrt(head_dim)</c> factor —
    /// magnitude is regulated by the learnable <c>q_norm</c>/<c>k_norm</c> scales.
    /// </remarks>
    public Tensor.Tensor Forward(
        Tensor.Tensor input,
        Tensor.Tensor qProjWeight,
        Tensor.Tensor kProjWeight,
        Tensor.Tensor vProjWeight,
        Tensor.Tensor oProjWeight,
        KvCache kvCache = null,
        int layerIndex = 0,
        Tensor.Tensor qNormWeight = null,
        Tensor.Tensor kNormWeight = null,
        float rmsNormEpsilon = 1e-6f,
        int? kvSharingTargetLayer = null)
    {
        var seqLen = input.Shape[0];
        var hiddenSize = input.Shape[1];

        // Project to Q always; K/V only when not KV-shared.
        var qProj = TensorOperations.MatMul(input, Transpose2D(qProjWeight));

        var qProjDim = qProj.Shape[1];

        if (qProjDim % _numQueryHeads != 0)
        {
            throw new InvalidOperationException(
                $"Q projection dimension {qProjDim} is not evenly divisible by the number of query heads {_numQueryHeads}.");
        }

        var qHeadDim = qProjDim / _numQueryHeads;

        // Derive the expected per-head output dimension from the o_proj weight.
        // PyTorch convention stores o_proj as [outFeatures=queries*outputHeadDim, hiddenSize].
        // GGUF stores it raw in the same [out, in] order (no transpose needed),
        // so the leading dimension is the per-head outputDim * numHeads.
        // Derive per-head output from o_proj. After the GgufWeightAdapter
        // transposes o_proj.weight into PyTorch [out, in] ordering, the *input*
        // dimension (axis 1) is the concatenation length we will route through
        // MatMul(concat, Transpose2D(weight)), so reading it from Shape[1]
        // preserves the contract used for q/k/v.
        var oProjConcatDim = oProjWeight.Shape[1];

        if (oProjConcatDim % _numQueryHeads != 0)
        {
            throw new InvalidOperationException(
                $"O projection concat dim {oProjConcatDim} is not evenly divisible by the number of query heads {_numQueryHeads}.");
        }

        var outputHeadDim = oProjConcatDim / _numQueryHeads;

        // Reshape Q to [numHeads, seqLen, headDim] and apply Q-norm + RoPE.
        var Q = ReshapeToHeads(qProj, _numQueryHeads, seqLen, qHeadDim);

        if (qNormWeight != null)
        {
            Q = TensorOperations.RmsNorm(Q, qNormWeight, rmsNormEpsilon);
        }

        var startPosition = kvCache?.GetSequenceLength(kvSharingTargetLayer ?? layerIndex) ?? 0;
        Q = _rope.Apply(Q, startPosition);

        Tensor.Tensor K;
        Tensor.Tensor V;
        int kHeadDim;
        int vHeadDim;

        if (kvSharingTargetLayer.HasValue)
        {
            // Shared layer: read K/V from the target layer's cache. K/V have
            // already had their own k_norm + v_norm + RoPE applied during
            // the target layer's forward pass.
            if (kvCache == null)
            {
                throw new InvalidOperationException(
                    "kvSharingTargetLayer requires a non-null kvCache.");
            }

            var sharedCached = kvCache.Get(kvSharingTargetLayer.Value);
            K = sharedCached.Keys;
            V = sharedCached.Values;
            kHeadDim = K.Shape[2];
            vHeadDim = V.Shape[2];
        }
        else
        {
            ArgumentNullException.ThrowIfNull(kProjWeight);
            ArgumentNullException.ThrowIfNull(vProjWeight);

            var kProj = TensorOperations.MatMul(input, Transpose2D(kProjWeight));
            var vProj = TensorOperations.MatMul(input, Transpose2D(vProjWeight));

            // Derive actual head dimensions from the projected tensor shapes
            // to avoid mismatches between config values and real weight sizes.
            // In Gemma-4 full attention layers with attention_k_eq_v:
            //   Q uses global_head_dim (e.g. 512) per query head
            //   K uses head_dim (e.g. 128) per KV head
            //   V shares K's weight, so also uses head_dim per KV head
            //   O expects numQueryHeads * global_head_dim (matches Q)
            // The gap between vHeadDim and the o_proj expected dimension is
            // bridged by concatenating unused Q dimensions ("pass-through").
            var kProjDim = kProj.Shape[1];
            var vProjDim = vProj.Shape[1];

            if (kProjDim % _numKvHeads != 0)
            {
                throw new InvalidOperationException(
                    $"K projection dimension {kProjDim} is not evenly divisible by the number of KV heads {_numKvHeads}.");
            }

            if (vProjDim % _numKvHeads != 0)
            {
                throw new InvalidOperationException(
                    $"V projection dimension {vProjDim} is not evenly divisible by the number of KV heads {_numKvHeads}.");
            }

            kHeadDim = kProjDim / _numKvHeads;
            vHeadDim = vProjDim / _numKvHeads;

            K = ReshapeToHeads(kProj, _numKvHeads, seqLen, kHeadDim);
            V = ReshapeToHeads(vProj, _numKvHeads, seqLen, vHeadDim);

            // per-head RMSNorm on K (Gemma-4 uses q_norm/k_norm before RoPE).
            if (kNormWeight != null)
            {
                K = TensorOperations.RmsNorm(K, kNormWeight, rmsNormEpsilon);
            }

            // scale-less value_norm
            V = TensorOperations.RmsNormNoWeight(V, rmsNormEpsilon);

            // apply RoPE to K
            K = _rope.Apply(K, startPosition);

            // append to own KV cache. Prefer the span-based path (no intermediate
            // tensor copy); the view returned by Get is a zero-copy slice into the
            // cache's pre-allocated buffer.
            if (kvCache != null)
            {
                // Idempotent reserve: ensure the cache has a buffer for this layer.
                // We don't know the model's context length from inside the attention
                // layer, so seed the capacity with the current call's seqLen and let
                // the cache double on demand. Gemma4Model calls Reserve() with the
                // real context length to avoid any growth during normal generation.
                if (!kvCache.HasLayer(layerIndex))
                {
                    kvCache.Reserve(layerIndex, _numKvHeads, _headDim, Math.Max(seqLen, 64));
                }
                kvCache.Append(layerIndex, K.DataSpan, V.DataSpan);
                var cached = kvCache.Get(layerIndex);
                K = cached.Keys;
                V = cached.Values;
            }
        }

        // handle GQA: repeat K,V heads to match Q heads
        if (_numKvHeads < _numQueryHeads)
        {
            var repeatFactor = _numQueryHeads / _numKvHeads;
            K = RepeatKvHeads(K, repeatFactor);
            V = RepeatKvHeads(V, repeatFactor);
        }

        // Compute attention scores: Q @ K^T / sqrt(dotDim)
        // When Q has a larger head dimension than K (asymmetric head dims),
        // the dot product uses only the first kHeadDim dimensions of Q.
        var kvSeqLen = K.Shape[1];
        var scores = ComputeAttentionScores(
            Q, K, _numQueryHeads, seqLen, kvSeqLen, qHeadDim, kHeadDim,
            _attentionLogitsSoftcap);

        // Apply attention mask
        ApplyMask(scores, seqLen, kvSeqLen, startPosition);

        // softmax over last dimension (numerically stable)
        scores = TensorOperations.SoftmaxStable(scores);

        // attention output: scores @ V (result has vHeadDim per head)
        var attnOutput = ComputeAttentionOutput(scores, V, _numQueryHeads, seqLen, kvSeqLen, vHeadDim);

        // When V's per-head dimension (vHeadDim) is smaller than what o_proj
        // expects (outputHeadDim), Q has extra dimensions beyond those used
        // in the dot product with K.  These "pass-through" dimensions are
        // concatenated with the attention output so the combined per-head
        // dimension matches o_proj.  This occurs in Gemma-4 full attention
        // layers when attention_k_eq_v is true (V = K, both use headDim)
        // while Q and o_proj use the larger globalHeadDim.
        if (vHeadDim < outputHeadDim)
        {
            var dotDim = Math.Min(qHeadDim, kHeadDim);
            var passThroughDim = outputHeadDim - vHeadDim;
            attnOutput = ConcatQPassThrough(attnOutput, Q, _numQueryHeads, seqLen, vHeadDim, dotDim, passThroughDim);
        }

        // Reshape from [numQueryHeads, seqLen, outputHeadDim] -> [seqLen, numQueryHeads * outputHeadDim]
        var concatenated = ReshapeFromHeads(attnOutput, _numQueryHeads, seqLen, outputHeadDim);

        // Output projection
        var output = TensorOperations.MatMul(concatenated, Transpose2D(oProjWeight));

        return output;
    }

    /// <summary>
    /// Returns a new tensor with the rows and columns of the specified 2D tensor exchanged.
    /// </summary>
    /// <param name="t">The 2D tensor to transpose. Must have a rank of 2.</param>
    /// <returns>A tensor representing the transposed version of the input tensor.</returns>
    /// <exception cref="ArgumentException">Thrown if the input tensor does not have a rank of 2.</exception>
    private static Tensor.Tensor Transpose2D(Tensor.Tensor t)
    {
        if (t.Rank != 2) throw new ArgumentException("Transpose2D requires 2D tensor.");
        return t.Transpose();
    }

    /// <summary>
    /// Reshapes [seqLen, numHeads * headDim] to [numHeads, seqLen, headDim].
    /// </summary>
    private static Tensor.Tensor ReshapeToHeads(Tensor.Tensor input, int numHeads, int seqLen, int headDim)
    {
        var data = input.Data;
        var expectedLength = seqLen * numHeads * headDim;

        if (data.Length < expectedLength)
        {
            throw new ArgumentException(
                $"Input tensor length {data.Length} is too small for the requested reshape " +
                $"(seqLen={seqLen}, numHeads={numHeads}, headDim={headDim}, expected={expectedLength}).");
        }

        var result = new float[numHeads * seqLen * headDim];

        for (var s = 0; s < seqLen; s++)
        {
            for (var h = 0; h < numHeads; h++)
            {
                var srcOffset = s * numHeads * headDim + h * headDim;
                var dstOffset = h * seqLen * headDim + s * headDim;
                Array.Copy(data, srcOffset, result, dstOffset, headDim);
            }
        }

        return new Tensor.Tensor([numHeads, seqLen, headDim], result);
    }

    /// <summary>
    /// Reshapes [numHeads, seqLen, headDim] to [seqLen, numHeads * headDim].
    /// </summary>
    private static Tensor.Tensor ReshapeFromHeads(Tensor.Tensor input, int numHeads, int seqLen, int headDim)
    {
        var data = input.Data;
        var result = new float[seqLen * numHeads * headDim];

        for (var s = 0; s < seqLen; s++)
        {
            for (var h = 0; h < numHeads; h++)
            {
                var srcOffset = h * seqLen * headDim + s * headDim;
                var dstOffset = s * numHeads * headDim + h * headDim;
                Array.Copy(data, srcOffset, result, dstOffset, headDim);
            }
        }

        return new Tensor.Tensor([seqLen, numHeads * headDim], result);
    }

    /// <summary>
    /// Concatenates Q pass-through dimensions with the attention output.
    /// When V's per-head dimension is smaller than o_proj's expected input,
    /// Q has unused dimensions (beyond those used for the K dot product)
    /// that are appended to the attention output for each head.
    /// </summary>
    private static Tensor.Tensor ConcatQPassThrough(
        Tensor.Tensor attnOutput, Tensor.Tensor Q,
        int numHeads, int seqLen, int vHeadDim, int dotDim, int passThroughDim)
    {
        var outputHeadDim = vHeadDim + passThroughDim;
        var qHeadDim = Q.Shape[2];
        var result = new float[numHeads * seqLen * outputHeadDim];

        for (var h = 0; h < numHeads; h++)
        {
            for (var s = 0; s < seqLen; s++)
            {
                var attnSrc = h * seqLen * vHeadDim + s * vHeadDim;
                var qSrc = h * seqLen * qHeadDim + s * qHeadDim + dotDim;
                var dst = h * seqLen * outputHeadDim + s * outputHeadDim;

                // Copy attention output (vHeadDim dimensions)
                Array.Copy(attnOutput.Data, attnSrc, result, dst, vHeadDim);

                // Copy Q pass-through (passThroughDim dimensions starting at dotDim)
                Array.Copy(Q.Data, qSrc, result, dst + vHeadDim, passThroughDim);
            }
        }

        return new Tensor.Tensor([numHeads, seqLen, outputHeadDim], result);
    }

    /// <summary>
    /// Repeats KV heads to match the number of query heads (for grouped-query attention).
    /// </summary>
    private static Tensor.Tensor RepeatKvHeads(Tensor.Tensor kv, int repeatFactor)
    {
        if (repeatFactor == 1) return kv;

        var numKvHeads = kv.Shape[0];
        var seqLen = kv.Shape[1];
        var headDim = kv.Shape[2];
        var newNumHeads = numKvHeads * repeatFactor;
        var result = new float[newNumHeads * seqLen * headDim];

        for (var h = 0; h < numKvHeads; h++)
        {
            for (var r = 0; r < repeatFactor; r++)
            {
                var srcOffset = h * seqLen * headDim;
                var dstOffset = (h * repeatFactor + r) * seqLen * headDim;
                Array.Copy(kv.Data, srcOffset, result, dstOffset, seqLen * headDim);
            }
        }

        return new Tensor.Tensor([newNumHeads, seqLen, headDim], result);
    }

    /// <summary>
    /// Computes Q @ K^T per head, optionally applying an attention-logits soft
    /// cap (<c>tanh(score / cap) * cap</c>) before the softmax. When Q and K
    /// have different per-head dimensions the dot product is computed over the
    /// smaller dimension (kHeadDim).
    /// </summary>
    /// <remarks>
    /// No <c>1/sqrt(head_dim)</c> factor is applied: the Gemma-4 reference
    /// uses a plain einsum and relies on the learnable <c>q_norm</c>/<c>k_norm</c>
    /// scales to control the score magnitude.
    /// </remarks>
    private static Tensor.Tensor ComputeAttentionScores(
        Tensor.Tensor Q, Tensor.Tensor K, int numHeads, int queryLen, int kvLen, int qHeadDim, int kHeadDim,
        float softcap)
    {
        var dotDim = Math.Min(qHeadDim, kHeadDim);
        var scores = new float[numHeads * queryLen * kvLen];
        var applySoftcap = softcap > 0f;

        Parallel.For(0, numHeads, h =>
        {
            var qOffset = h * queryLen * qHeadDim;
            var kOffset = h * kvLen * kHeadDim;
            var sOffset = h * queryLen * kvLen;

            for (var i = 0; i < queryLen; i++)
            {
                for (var j = 0; j < kvLen; j++)
                {
                    var dot = 0.0f;

                    for (var d = 0; d < dotDim; d++)
                    {
                        dot += Q.Data[qOffset + i * qHeadDim + d] * K.Data[kOffset + j * kHeadDim + d];
                    }

                    var score = dot;

                    if (applySoftcap)
                    {
                        score = MathF.Tanh(score / softcap) * softcap;
                    }

                    scores[sOffset + i * kvLen + j] = score;
                }
            }
        });

        return new Tensor.Tensor([numHeads, queryLen, kvLen], scores);
    }

    /// <summary>
    /// Applies causal and/or sliding window mask in place.
    /// </summary>
    private void ApplyMask(Tensor.Tensor scores, int queryLen, int kvLen, int startPosition)
    {
        var numHeads = scores.Shape[0];
        var sData = scores.Data;

        // Each head writes to a disjoint [queryLen, kvLen] slice; safe to parallelize.
        Parallel.For(0, numHeads, h =>
        {
            var headBase = h * queryLen * kvLen;

            for (var i = 0; i < queryLen; i++)
            {
                var queryPos = startPosition + i;
                var rowBase = headBase + i * kvLen;

                for (var j = 0; j < kvLen; j++)
                {
                    // Causal mask: cannot attend to future positions
                    if (j > queryPos)
                    {
                        sData[rowBase + j] = MaskValue;
                        continue;
                    }

                    // Sliding window mask (only for sliding attention layers)
                    if (!_isFullAttention && queryPos - j >= _slidingWindowSize)
                    {
                        sData[rowBase + j] = MaskValue;
                    }
                }
            }
        });
    }

    /// <summary>
    /// Computes softmax(scores) @ V for each head.
    /// </summary>
    private static Tensor.Tensor ComputeAttentionOutput(
        Tensor.Tensor scores, Tensor.Tensor V, int numHeads, int queryLen, int kvLen, int headDim)
    {
        var result = new float[numHeads * queryLen * headDim];
        var sData = scores.Data;
        var vData = V.Data;

        // Each head writes to a disjoint slice of `result`; safe to parallelize.
        Parallel.For(0, numHeads, h =>
        {
            var sOffset = h * queryLen * kvLen;
            var vOffset = h * kvLen * headDim;
            var rOffset = h * queryLen * headDim;

            for (var i = 0; i < queryLen; i++)
            {
                for (var d = 0; d < headDim; d++)
                {
                    var sum = 0.0f;

                    for (var j = 0; j < kvLen; j++)
                    {
                        sum += sData[sOffset + i * kvLen + j] * vData[vOffset + j * headDim + d];
                    }

                    result[rOffset + i * headDim + d] = sum;
                }
            }
        });

        return Tensor.Tensor.Owning([numHeads, queryLen, headDim], result);
    }
}
